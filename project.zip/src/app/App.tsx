import { motion, AnimatePresence } from "motion/react";
import { Map, Wallet, Clock, BrainCircuit, Phone, Mail, ChevronRight, Menu, X, Instagram, Twitter, Facebook, Landmark, MapPin, ArrowLeft, Send, Sparkles, Loader2, DollarSign, Home, Utensils, Car, Camera, MessageCircle, User, Lock, Eye, EyeOff, LogOut, Calendar, Users, Plane, Train, Bus, CarFront, Bike, Ship, Info, ArrowRight, Check } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./components/ui/card";
import { Sheet, SheetContent, SheetTrigger } from "./components/ui/sheet";
import { RouteMap } from "./components/RouteMap";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "./components/ui/dialog";
import { ScrollArea } from "./components/ui/scroll-area";
import { stateDetails } from "./stateData";
import { indianStates } from "./indianStates";
import { districtData } from "./districtData";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isPlanningOpen, setIsPlanningOpen] = useState(false);
  const [selectedState, setSelectedState] = useState<string | null>(null);
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null);
  const [aiMessages, setAiMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([]);
  const [userInput, setUserInput] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [showChatbot, setShowChatbot] = useState(false);
  const [selectedBudgetPlace, setSelectedBudgetPlace] = useState<{ name: string; type: string; imageUrl: string } | null>(null);
  
  // Authentication states
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [signUpName, setSignUpName] = useState('');
  const [userName, setUserName] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [isAiChatOpen, setIsAiChatOpen] = useState(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);
  
  // Booking states
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingStep, setBookingStep] = useState(1);
  const [fromDestination, setFromDestination] = useState('');
  const [toDestination, setToDestination] = useState('');
  const [departureDate, setDepartureDate] = useState('');
  const [returnDate, setReturnDate] = useState('');
  const [travelers, setTravelers] = useState(1);
  const [travelClass, setTravelClass] = useState('economy');
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [transportMode, setTransportMode] = useState('flight');
  
  // Flight specific
  const [flightType, setFlightType] = useState('roundtrip');
  const [cabinClass, setCabinClass] = useState('economy');
  const [preferredAirline, setPreferredAirline] = useState('');
  
  // Train specific
  const [trainClass, setTrainClass] = useState('sleeper');
  const [berthPreference, setBerthPreference] = useState('lower');
  const [trainType, setTrainType] = useState('express');
  
  // Bus specific
  const [busType, setBusType] = useState('sleeper');
  const [seatType, setSeatType] = useState('window');
  const [acPreference, setAcPreference] = useState('ac');
  
  // Car/Taxi specific
  const [carType, setCarType] = useState('sedan');
  const [withDriver, setWithDriver] = useState(true);
  const [fuelType, setFuelType] = useState('petrol');
  
  // Bike specific
  const [bikeType, setBikeType] = useState('standard');
  const [helmetRequired, setHelmetRequired] = useState(true);

  // Map tracking
  const [showRouteMap, setShowRouteMap] = useState(false);

  // Initialize Gemini AI
  const genAI = new GoogleGenerativeAI("AIzaSyBlF0QvwQDm6MdNbGY4nsFJIImUKoT9SJw");

  // Scroll detection for navbar
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [aiMessages]);

  // Reset AI chat when state changes
  useEffect(() => {
    if (selectedState) {
      setAiMessages([{
        role: 'assistant',
        content: `Hello! I'm your AI travel assistant for ${selectedState}. I can help you with:\n\n✈️ Best time to visit\n Hotel recommendations\n🍽️ Local cuisine suggestions\n🚗 Transportation tips\n📸 Hidden gems & photo spots\n💰 Budget planning\n\nWhat would you like to know about traveling to ${selectedState}?`
      }]);
    } else {
      setAiMessages([]);
    }
  }, [selectedState]);

  const handleAiChat = async () => {
    if (!userInput.trim() || isAiLoading) return;

    const userMessage = userInput.trim();
    setUserInput('');
    setIsAiLoading(true);

    // Add user message
    setAiMessages(prev => [...prev, { role: 'user', content: userMessage }]);

    // Simulate AI thinking time for better UX
    await new Promise(resolve => setTimeout(resolve, 800));

    // Generate intelligent demo response
    const demoResponse = generateDemoResponse(userMessage, selectedState!);
    setAiMessages(prev => [...prev, { 
      role: 'assistant', 
      content: demoResponse
    }]);
    
    setIsAiLoading(false);
  };

  // Demo response generator for when API is unavailable
  const generateDemoResponse = (question: string, state: string): string => {
    const lowerQuestion = question.toLowerCase();
    
    if (lowerQuestion.includes('hotel') || lowerQuestion.includes('stay') || lowerQuestion.includes('accommodation')) {
      return `🏨 **Hotel Recommendations for ${state}:**\n\n✨ Budget-Friendly:\n• Local guesthouses (₹800-1500/night)\n• Budget hotels near main attractions\n\n⭐ Mid-Range:\n• 3-star hotels (₹2500-4500/night)\n• Good amenities and location\n\n💎 Luxury:\n• 5-star resorts and heritage hotels\n• Premium experience (₹8000+/night)\n\nTip: Book in advance during peak season for better rates!`;
    }
    
    if (lowerQuestion.includes('food') || lowerQuestion.includes('cuisine') || lowerQuestion.includes('eat')) {
      return `🍽️ **Must-Try Cuisine in ${state}:**\n\n🌶️ Local Specialties:\n• Regional delicacies unique to ${state}\n• Street food at local markets\n• Traditional thalis for authentic taste\n\n🥘 Popular Dishes:\n• Visit local eateries for authentic flavors\n• Try breakfast specialties\n• Don't miss the sweets!\n\n💡 Pro Tip: Ask locals for their favorite spots - they know the best hidden gems!`;
    }
    
    if (lowerQuestion.includes('time') || lowerQuestion.includes('when') || lowerQuestion.includes('season') || lowerQuestion.includes('weather')) {
      return `📅 **Best Time to Visit ${state}:**\n\n🌞 Peak Season:\n• October to March (pleasant weather)\n• Perfect for sightseeing\n• Book accommodations early\n\n🌧️ Monsoon:\n• July to September\n• Lush green landscapes\n• Fewer tourists, better prices\n\n☀️ Summer:\n• April to June (can be hot)\n• Off-season discounts available\n\nRecommendation: October-February is ideal for most activities!`;
    }
    
    if (lowerQuestion.includes('transport') || lowerQuestion.includes('travel') || lowerQuestion.includes('reach') || lowerQuestion.includes('get around')) {
      return `🚗 **Transportation in ${state}:**\n\n✈️ Getting There:\n• Major airports in the state\n• Railway connectivity to main cities\n• Bus services from neighboring states\n\n🚕 Local Transport:\n• Taxi/cab services (Uber, Ola available)\n• Auto-rickshaws for short distances\n• Rental cars for flexibility\n\n🚌 Public Transport:\n• State-run buses (economical)\n• Metro (if available in major cities)\n\n💡 Tip: Pre-book cabs for airport transfers!`;
    }
    
    if (lowerQuestion.includes('budget') || lowerQuestion.includes('cost') || lowerQuestion.includes('expensive') || lowerQuestion.includes('cheap')) {
      return `💰 **Budget Planning for ${state}:**\n\n💵 Budget Traveler (₹1500-2500/day):\n• Budget hotels/hostels\n• Local food and street eats\n• Public transport\n\n💳 Mid-Range (₹3000-6000/day):\n• Comfortable 3-star hotels\n• Mix of local and restaurant dining\n• Private cabs for sightseeing\n\n💎 Luxury (₹8000+/day):\n• Premium hotels/resorts\n• Fine dining experiences\n• Private guided tours\n\nTip: Visiting during off-season can save 30-40%!`;
    }
    
    if (lowerQuestion.includes('photo') || lowerQuestion.includes('instagram') || lowerQuestion.includes('spot') || lowerQuestion.includes('scenic')) {
      return `📸 **Best Photo Spots in ${state}:**\n\n🌅 Sunrise/Sunset Points:\n• Hilltop viewpoints\n• Waterfront locations\n• Heritage monuments\n\n🏛️ Architectural Marvels:\n• Historic forts and palaces\n• Temples and religious sites\n• Colonial architecture\n\n🌿 Natural Beauty:\n• Landscapes and valleys\n• Waterfalls and lakes\n• Gardens and parks\n\n💡 Golden Hour Tip: Early morning (6-8 AM) and evening (5-7 PM) offer the best lighting!`;
    }
    
    // Default response
    return `✨ **About ${state}:**\n\n${state} is a wonderful destination with rich culture and amazing attractions! Here's what you should know:\n\n🏛️ Must-Visit Places:\n${stateDetails[state]?.slice(0, 3).map(p => `• ${p.name}`).join('\n') || '• Check out the featured destinations'}\n\n🎯 Quick Tips:\n• Plan at least 3-4 days to explore properly\n• Respect local customs and traditions\n• Carry comfortable walking shoes\n• Stay hydrated, especially in summer\n\n💬 Ask me about:\n• Hotels & accommodation\n• Local food & cuisine\n• Best time to visit\n• Transportation options\n• Budget planning\n• Photo spots\n\nWhat specific aspect would you like to know more about?`;
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  // Handle login/signup
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginEmail && loginPassword) {
      setIsLoggedIn(true);
      setUserName(loginEmail.split('@')[0]);
      setIsLoginOpen(false);
      setLoginEmail('');
      setLoginPassword('');
    }
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (signUpName && loginEmail && loginPassword) {
      setIsLoggedIn(true);
      setUserName(signUpName);
      setIsLoginOpen(false);
      setSignUpName('');
      setLoginEmail('');
      setLoginPassword('');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserName('');
    setIsPlanningOpen(false);
    setSelectedState(null);
    setSelectedDistrict(null);
  };

  const handlePlanningClick = () => {
    if (!isLoggedIn) {
      setIsLoginOpen(true);
    } else {
      setIsPlanningOpen(true);
    }
  };

  const handleBookNowClick = () => {
    if (!isLoggedIn) {
      setIsLoginOpen(true);
    } else {
      setIsBookingOpen(true);
      setBookingStep(1);
      setShowRouteMap(false);
    }
  };

  const handleBookingNext = () => {
    // Hide map when moving to next step
    setShowRouteMap(false);
    
    // Validation for each step
    if (bookingStep === 1) {
      // Transport mode is already selected by default
      setBookingStep(2);
    } else if (bookingStep === 2) {
      // Check if destinations and dates are filled
      if (!fromDestination || !toDestination || !departureDate || !returnDate) {
        alert('Please fill in all journey details before continuing.');
        return;
      }
      setBookingStep(3);
    } else if (bookingStep === 3) {
      // Transport-specific fields are optional, can proceed
      setBookingStep(4);
    }
  };

  const handleBookingBack = () => {
    // Hide map when moving back
    setShowRouteMap(false);
    
    if (bookingStep > 1) {
      setBookingStep(bookingStep - 1);
    }
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isLoggedIn) {
      setIsLoginOpen(true);
      return;
    }
    
    // Build transport-specific details
    let transportDetails: any = {
      mode: transportMode,
      from: fromDestination,
      to: toDestination,
      departure: departureDate,
      return: returnDate,
      travelers,
    };

    if (transportMode === 'flight') {
      transportDetails = { ...transportDetails, flightType, cabinClass, preferredAirline };
    } else if (transportMode === 'train') {
      transportDetails = { ...transportDetails, trainClass, berthPreference, trainType };
    } else if (transportMode === 'bus') {
      transportDetails = { ...transportDetails, busType, seatType, acPreference };
    } else if (transportMode === 'car') {
      transportDetails = { ...transportDetails, carType, withDriver, fuelType };
    } else if (transportMode === 'bike') {
      transportDetails = { ...transportDetails, bikeType, helmetRequired };
    }
    
    // Handle booking submission
    console.log('Booking Details:', transportDetails);
    
    // Show success message (you can replace with actual booking logic)
    alert(`Booking Submitted!\nFrom: ${fromDestination}\nTo: ${toDestination}\nDeparture: ${departureDate}\nReturn: ${returnDate}\nTravelers: ${travelers}\nClass: ${travelClass}`);
    
    // Reset form
    setFromDestination('');
    setToDestination('');
    setDepartureDate('');
    setReturnDate('');
    setTravelers(1);
    setTravelClass('economy');
    setTransportMode('flight');
    setBookingStep(1);
    setShowRouteMap(false);
    setIsBookingOpen(false);
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 text-white overflow-x-hidden selection:bg-cyan-500/30">
      {/* Vibrant Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-gradient-to-r from-emerald-500/15 to-teal-500/15 rounded-full blur-[100px]" />
      </div>
      
      {/* Navbar */}
      <header 
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 border-b border-white/0 ${
          isScrolled ? "bg-background/80 backdrop-blur-md border-white/10 py-4 shadow-lg" : "bg-transparent py-6"
        }`}
      >
        <div className="container mx-auto px-6 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-primary to-secondary flex items-center justify-center">
              <Map className="w-5 h-5 text-background" />
            </div>
            <h1 className="text-xl md:text-2xl font-bold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white to-white/70">
              IAGI WARRIORS
            </h1>
          </motion.div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {([
              { name: "Home", color: "hover:text-cyan-400" },
              { name: "Features", color: "hover:text-purple-400" },
              { name: "Book Now", color: "hover:text-pink-400", action: handleBookNowClick },
              { name: "About", color: "hover:text-emerald-400" },
              { name: "Contact", color: "hover:text-orange-400" }
            ] as Array<{ name: string; color: string; action?: () => void }>).map((item, i) => (
              <motion.button
                key={item.name}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i }}
                onClick={() => item.action ? item.action() : scrollToSection(item.name.toLowerCase())}
                className={`text-sm font-medium text-white/90 ${item.color} transition-colors uppercase tracking-widest hover:scale-110 hover:font-bold transition-all duration-300`}
              >
                {item.name}
              </motion.button>
            ))}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 }}
              className="flex items-center gap-3"
            >
              {isLoggedIn ? (
                <>
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center">
                      <User className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-sm font-medium text-white">{userName}</span>
                  </div>
                  <Button 
                    onClick={handleLogout}
                    variant="outline"
                    className="border-red-500/50 text-red-400 hover:bg-red-500/10 hover:text-red-300 rounded-full px-4"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </>
              ) : (
                <Button 
                  onClick={() => setIsLoginOpen(true)}
                  className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-6 font-semibold shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] transition-all"
                >
                  Login / Sign Up
                </Button>
              )}
            </motion.div>
          </nav>

          {/* Mobile Nav */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <button className="p-2 rounded-md hover:bg-white/10 transition-colors text-white">
                  <Menu className="w-6 h-6" />
                </button>
              </SheetTrigger>
              <SheetContent className="bg-background/95 border-l border-white/10 backdrop-blur-xl">
                <nav className="flex flex-col gap-6 mt-10">
                  {([
                    { name: "Home", color: "hover:text-cyan-400" },
                    { name: "Features", color: "hover:text-purple-400" },
                    { name: "Book Now", color: "hover:text-pink-400", action: handleBookNowClick },
                    { name: "About", color: "hover:text-emerald-400" },
                    { name: "Contact", color: "hover:text-orange-400" }
                  ] as Array<{ name: string; color: string; action?: () => void }>).map((item) => (
                    <button
                      key={item.name}
                      onClick={() => item.action ? item.action() : scrollToSection(item.name.toLowerCase())}
                      className={`text-2xl font-bold text-left text-white ${item.color} transition-colors`}
                    >
                      {item.name}
                    </button>
                  ))}
                  
                  <div className="mt-6 pt-6 border-t border-white/10">
                    {isLoggedIn ? (
                      <>
                        <div className="flex items-center gap-3 mb-4 p-3 rounded-xl bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center">
                            <User className="w-5 h-5 text-white" />
                          </div>
                          <span className="text-lg font-semibold text-white">{userName}</span>
                        </div>
                        <Button 
                          onClick={handleLogout}
                          variant="outline"
                          className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10 hover:text-red-300"
                        >
                          <LogOut className="w-4 h-4 mr-2" />
                          Logout
                        </Button>
                      </>
                    ) : (
                      <Button 
                        onClick={() => setIsLoginOpen(true)}
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                      >
                        Login / Sign Up
                      </Button>
                    )}
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image with Gradient Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1606933988011-8adbb3ee269a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBhZHZlbnR1cmUlMjB3b3JsZCUyMG1hcCUyMGV4cGxvcmV8ZW58MXx8fHwxNzcwNzI5OTA0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Travel Adventure World Map" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/30" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-background/80" />
        </div>

        <div className="container relative z-10 px-6 pt-20 text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-6">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-xs font-medium tracking-wide uppercase text-primary">
                {isLoggedIn ? `Welcome back, ${userName}! 👋` : 'Next Gen Travel Planning'}
              </span>
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tight mb-6 leading-[1.1]">
              <span className="block text-white drop-shadow-lg">Discover Places</span>
              <span className="text-black drop-shadow-[0_2px_10px_rgba(255,255,255,0.8)]">
                Maps Can't Show
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-white font-semibold mb-10 max-w-2xl mx-auto leading-relaxed drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)] bg-black/30 backdrop-blur-sm py-4 px-6 rounded-2xl border border-white/20">
              AI-powered personalized travel planning for smarter journeys. 
              Escape the generic and experience the unique.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button 
                onClick={handlePlanningClick}
                className="h-14 px-8 rounded-full text-lg bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:scale-105 transition-all duration-300 font-semibold inline-flex items-center justify-center"
              >
                Start Planning <ChevronRight className="ml-2 w-5 h-5" />
              </button>
              
              <button 
                onClick={handleBookNowClick}
                className="h-14 px-8 rounded-full text-lg bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700 shadow-[0_0_20px_rgba(168,85,247,0.4)] hover:scale-105 transition-all duration-300 font-semibold inline-flex items-center justify-center"
              >
                Book Now <Calendar className="ml-2 w-5 h-5" />
              </button>
              
              <Dialog open={isPlanningOpen} onOpenChange={setIsPlanningOpen}>
                <DialogContent className="max-w-4xl max-h-[90vh] bg-background/95 backdrop-blur-xl border-white/10">
                  {!selectedState ? (
                    <>
                      <DialogHeader>
                        <DialogTitle className="text-3xl font-bold">Where to Next?</DialogTitle>
                        <DialogDescription className="text-muted-foreground">
                          Explore 29 states across India. Select a state to discover districts & tourist places.
                        </DialogDescription>
                      </DialogHeader>
                      <ScrollArea className="h-[60vh] mt-4 pr-4">
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 pb-4">
                          {indianStates.map((state) => (
                            <button
                              key={state.name}
                              onClick={() => {
                                setSelectedState(state.name);
                                setSelectedDistrict(null);
                              }}
                              className="relative flex flex-col p-0 rounded-xl bg-slate-900/90 border-2 border-slate-700/50 hover:border-cyan-500/70 transition-all duration-300 text-left group overflow-hidden hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-cyan-500/20"
                            >
                              <div className="relative w-full aspect-video overflow-hidden">
                                <img 
                                  src={state.imageUrl} 
                                  alt={state.landmark}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
                              </div>
                              <div className="p-4 bg-slate-900">
                                <p className="font-bold text-sm text-white leading-tight mb-1.5">{state.name}</p>
                                <div className="flex items-center gap-1.5 text-slate-400 group-hover:text-cyan-400 transition-colors">
                                  <MapPin className="w-3 h-3 flex-shrink-0" />
                                  <p className="text-xs leading-tight">
                                    {state.landmark}
                                  </p>
                                </div>
                              </div>
                            </button>
                          ))}
                        </div>
                      </ScrollArea>
                    </>
                  ) : !selectedDistrict ? (
                    <>
                      <DialogHeader>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => {
                              setSelectedState(null);
                              setSelectedDistrict(null);
                            }}
                            className="p-2 hover:bg-slate-200 rounded-lg transition-colors bg-white text-black"
                          >
                            <ArrowLeft className="w-5 h-5" />
                          </button>
                          <div>
                            <DialogTitle className="text-3xl font-bold">{selectedState} Districts</DialogTitle>
                            <DialogDescription className="text-muted-foreground">
                              Select a district to explore tourist destinations
                            </DialogDescription>
                          </div>
                        </div>
                      </DialogHeader>
                      <ScrollArea className="h-[60vh] mt-4 pr-4">
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pb-4">
                          {districtData[selectedState]?.map((district, index) => (
                            <button
                              key={index}
                              onClick={() => setSelectedDistrict(district.name)}
                              className="relative flex flex-col p-4 rounded-xl bg-gradient-to-br from-slate-900 to-slate-800 border-2 border-slate-700/50 hover:border-purple-500/70 transition-all duration-300 text-left group hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-purple-500/20"
                            >
                              <div className="flex items-center gap-3 mb-2">
                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
                                  <Landmark className="w-6 h-6 text-white" />
                                </div>
                                <div className="flex-1">
                                  <h3 className="font-bold text-white text-base leading-tight">{district.name}</h3>
                                  <p className="text-xs text-slate-400 mt-0.5">{district.places.length} Places</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 text-purple-400 group-hover:text-purple-300 transition-colors mt-2">
                                <ChevronRight className="w-4 h-4" />
                                <span className="text-xs font-semibold">Explore District</span>
                              </div>
                            </button>
                          )) || (
                            <div className="col-span-full text-center py-12 text-slate-400">
                              <p>Districts data coming soon for {selectedState}!</p>
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    </>
                  ) : (
                    <>
                      <DialogHeader>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => setSelectedDistrict(null)}
                            className="p-2 hover:bg-slate-200 rounded-lg transition-colors bg-white text-black"
                          >
                            <ArrowLeft className="w-5 h-5" />
                          </button>
                          <div>
                            <DialogTitle className="text-3xl font-bold">{selectedDistrict}</DialogTitle>
                            <DialogDescription className="text-muted-foreground">
                              {selectedState} • Discover amazing tourist destinations
                            </DialogDescription>
                          </div>
                        </div>
                      </DialogHeader>
                      <ScrollArea className="h-[60vh] mt-4 pr-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4">
                          {districtData[selectedState]?.find(d => d.name === selectedDistrict)?.places.map((place, index) => (
                            <div
                              key={index}
                              className="relative flex flex-col rounded-xl bg-slate-900/90 border-2 border-slate-700/50 hover:border-cyan-500/70 transition-all duration-300 overflow-hidden group hover:scale-[1.02] shadow-lg hover:shadow-cyan-500/20"
                            >
                              <div className="relative w-full aspect-video overflow-hidden">
                                <img 
                                  src={place.imageUrl} 
                                  alt={place.name}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                />
                                <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-slate-900/80 backdrop-blur-sm border border-cyan-500/30">
                                  <span className="text-xs font-semibold text-cyan-400">{place.type}</span>
                                </div>
                                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                              </div>
                              <div className="p-5 bg-slate-900">
                                <h3 className="font-bold text-lg text-white leading-tight mb-2">{place.name}</h3>
                                <p className="text-sm text-slate-400 leading-relaxed mb-3">
                                  {place.description}
                                </p>
                                <button
                                  onClick={() => setSelectedBudgetPlace(place)}
                                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-semibold text-sm transition-all duration-300 hover:scale-[1.02] shadow-lg shadow-emerald-500/30"
                                >
                                  <Wallet className="w-4 h-4" />
                                  View Budget
                                </button>
                              </div>
                            </div>
                          )) || (
                            <div className="col-span-full text-center py-12 text-slate-400">
                              <p>More destinations coming soon for {selectedState}!</p>
                            </div>
                          )}
                        </div>
                        
                        {/* AI Travel Assistant - Inside State Details */}
                        <div className="mt-8 bg-gradient-to-br from-slate-900/50 via-slate-800/50 to-slate-900/50 border border-cyan-500/20 rounded-2xl p-6 backdrop-blur-sm">
                          <div className="flex items-center gap-3 mb-4">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-cyan-500 to-purple-600 flex items-center justify-center">
                              <Sparkles className="w-5 h-5 text-white animate-pulse" />
                            </div>
                            <div>
                              <h3 className="text-lg font-bold text-white">AI Travel Assistant</h3>
                              <p className="text-xs text-slate-400">Ask me anything about {selectedDistrict}, {selectedState}</p>
                            </div>
                          </div>
                          
                          {/* Chat Messages */}
                          <div className="max-h-[400px] overflow-y-auto mb-4 space-y-3 bg-slate-950/50 rounded-xl p-4">
                            <div ref={chatScrollRef} className="space-y-3">
                              {aiMessages.map((msg, idx) => (
                                <div 
                                  key={idx} 
                                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                  <div 
                                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm ${
                                      msg.role === 'user' 
                                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white' 
                                        : 'bg-slate-800/90 text-slate-200 border border-slate-700/50'
                                    }`}
                                  >
                                    <p className="leading-relaxed whitespace-pre-line text-xs">{msg.content}</p>
                                  </div>
                                </div>
                              ))}
                              {isAiLoading && (
                                <div className="flex justify-start">
                                  <div className="bg-slate-800/90 border border-slate-700/50 rounded-2xl px-4 py-2.5">
                                    <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                          
                          {/* Input Area */}
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={userInput}
                              onChange={(e) => setUserInput(e.target.value)}
                              onKeyPress={(e) => e.key === 'Enter' && handleAiChat()}
                              placeholder="Ask me anything..."
                              className="flex-1 px-4 py-3 text-sm rounded-full bg-slate-800/90 border border-slate-700/50 text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                              disabled={isAiLoading}
                            />
                            <button
                              onClick={handleAiChat}
                              disabled={isAiLoading || !userInput.trim()}
                              className="px-5 py-3 rounded-full bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 shadow-lg shadow-cyan-500/30"
                            >
                              <Send className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </ScrollArea>
                    </>
                  )}
                </DialogContent>
              </Dialog>
              <Button 
                size="lg" 
                variant="outline" 
                onClick={() => scrollToSection('about')}
                className="h-14 px-8 rounded-full text-lg border-2 border-white/50 bg-white/20 hover:bg-white/30 text-white backdrop-blur-md hover:scale-105 transition-all duration-300 font-semibold shadow-[0_0_30px_rgba(255,255,255,0.3)] hover:shadow-[0_0_40px_rgba(255,255,255,0.5)]"
              >
                Learn More
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator - Right Corner */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 1, duration: 1 }}
          className="fixed bottom-10 right-10 z-30 flex flex-col items-center gap-2 text-white/70 hover:text-white transition-colors group cursor-pointer"
          onClick={() => scrollToSection('features')}
        >
          <span className="text-xs uppercase tracking-widest font-semibold">Scroll</span>
          <div className="w-[2px] h-16 bg-gradient-to-b from-cyan-400 to-transparent rounded-full group-hover:h-20 transition-all duration-300" />
          <ChevronRight className="w-5 h-5 rotate-90 text-cyan-400 animate-bounce" />
        </motion.div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 md:py-32 relative">
        <div className="container mx-auto px-6">
          <motion.div 
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">Key Features</h2>
            <p className="text-slate-300 max-w-xl mx-auto">
              We've reimagined travel planning with intelligence at the core.
            </p>
          </motion.div>

          <motion.div 
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {features.map((feature, i) => (
              <motion.div variants={fadeInUp} key={i}>
                <Card className={`bg-gradient-to-br ${feature.cardGradient} border-2 ${feature.borderColor} hover:border-opacity-100 transition-all duration-300 h-full overflow-hidden group hover:scale-105 hover:shadow-2xl ${feature.shadowColor}`}>
                  <CardHeader>
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 shadow-xl`}>
                      <feature.icon className="w-7 h-7 text-white" />
                    </div>
                    <CardTitle className="text-xl font-bold text-white">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-200 leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 md:py-32 bg-secondary/5 border-y border-white/5">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl md:text-6xl font-bold mb-8 leading-tight">
                Plan less. <br />
                <span className="text-secondary">Travel better.</span>
              </h2>
              <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
                <p>
                  At IAGI Warriors, we believe that the best journeys aren't found in generic guidebooks. They're discovered through deep personalization and intelligent understanding of what moves you.
                </p>
                <p>
                  We build AI-driven travel solutions that eliminate the friction of planning, delivering unique itineraries that adapt to your style, budget, and dreams.
                </p>
              </div>
              <Button variant="link" className="mt-8 text-primary p-0 h-auto text-lg hover:text-primary/80">
                Read our story <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative aspect-square md:aspect-video lg:aspect-square rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-black/50"
            >
               {/* Decorative elements */}
               <div className="absolute top-10 right-10 w-20 h-20 bg-primary/20 blur-3xl rounded-full" />
               <div className="absolute bottom-10 left-10 w-32 h-32 bg-secondary/20 blur-3xl rounded-full" />
               
               <div className="absolute inset-0 flex items-center justify-center p-8">
                  <div className="grid grid-cols-2 gap-4 w-full h-full">
                    <div className="bg-white/5 rounded-lg border border-white/10 p-6 flex flex-col justify-end">
                       <span className="text-4xl font-bold text-primary mb-2">98%</span>
                       <span className="text-sm text-muted-foreground uppercase tracking-wider">Satisfaction</span>
                    </div>
                    <div className="bg-white/5 rounded-lg border border-white/10 p-6 flex flex-col justify-end translate-y-8">
                       <span className="text-4xl font-bold text-secondary mb-2">24/7</span>
                       <span className="text-sm text-muted-foreground uppercase tracking-wider">AI Support</span>
                    </div>
                    <div className="bg-white/5 rounded-lg border border-white/10 p-6 flex flex-col justify-end -translate-y-8">
                       <span className="text-4xl font-bold text-white mb-2">10k+</span>
                       <span className="text-sm text-muted-foreground uppercase tracking-wider">Routes</span>
                    </div>
                    <div className="bg-white/5 rounded-lg border border-white/10 p-6 flex flex-col justify-end">
                       <span className="text-4xl font-bold text-accent mb-2">0s</span>
                       <span className="text-sm text-muted-foreground uppercase tracking-wider">Wait Time</span>
                    </div>
                  </div>
               </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 relative">
        {/* Colorful background glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/4 w-[400px] h-[400px] bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-full blur-[100px]" />
          <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-full blur-[100px]" />
        </div>
        
        <div className="container mx-auto px-6 max-w-4xl text-center relative z-10">
          <motion.div 
             initial={{ opacity: 0, y: 20 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-12 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-white to-purple-400">Get in Touch</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              <Card className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-2 border-cyan-500/30 hover:border-cyan-400 p-6 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/30">
                <CardContent className="flex flex-col items-center gap-4 pt-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-xl shadow-cyan-500/50">
                    <Phone className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold text-white">Call Us</h3>
                  <div className="text-slate-200 space-y-2 font-medium">
                    <p>9741961251</p>
                    <p>7619405448</p>
                    <p>8971211401</p>
                    <p>9108339264</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-2 border-purple-500/30 hover:border-purple-400 p-6 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/30">
                 <CardContent className="flex flex-col items-center gap-4 pt-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-white shadow-xl shadow-purple-500/50">
                    <Mail className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold text-white">Email Us</h3>
                  <div className="text-slate-200 space-y-2 font-medium">
                    <p>hello@iagiwarriors.com</p>
                    <p>support@iagiwarriors.com</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 border-2 border-indigo-500/30 rounded-2xl p-8 backdrop-blur-sm">
              <h3 className="text-2xl font-bold mb-6 text-white">The Team</h3>
              <div className="flex flex-wrap justify-center gap-4 md:gap-6">
                {[
                  { name: "Vignesh", color: "from-cyan-500 to-blue-500" },
                  { name: "Sarath Kumar", color: "from-purple-500 to-pink-500" },
                  { name: "Thanvanth", color: "from-emerald-500 to-teal-500" },
                  { name: "Tejas Kumar", color: "from-amber-500 to-orange-500" }
                ].map((member) => (
                  <span key={member.name} className={`px-6 py-3 rounded-full bg-gradient-to-r ${member.color} text-white font-semibold border-2 border-white/20 hover:border-white/50 hover:scale-110 transition-all cursor-default shadow-lg`}>
                    {member.name}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/10 bg-black/40">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-primary to-secondary flex items-center justify-center">
                <Map className="w-3 h-3 text-background" />
              </div>
              <span className="font-bold tracking-tight">IAGI WARRIORS</span>
            </div>
            
            <p className="text-sm text-muted-foreground">
              © 2026 IAGI Warriors | Tourism & Travel Tech
            </p>

            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground hover:text-white transition-colors"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="text-muted-foreground hover:text-white transition-colors"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="text-muted-foreground hover:text-white transition-colors"><Facebook className="w-5 h-5" /></a>
            </div>
          </div>
        </div>
      </footer>
      
      {/* Budget Dialog */}
      <Dialog open={!!selectedBudgetPlace} onOpenChange={() => setSelectedBudgetPlace(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 backdrop-blur-xl border-2 border-emerald-500/30 shadow-2xl overflow-hidden">
          {selectedBudgetPlace && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setSelectedBudgetPlace(null)}
                    className="p-2.5 hover:bg-emerald-500/20 rounded-xl transition-all duration-300 bg-emerald-500/10 border border-emerald-500/30 hover:border-emerald-500/50 hover:scale-110 group"
                  >
                    <ArrowLeft className="w-5 h-5 text-emerald-400 group-hover:text-emerald-300 transition-colors" />
                  </button>
                  <div className="flex-1">
                    <DialogTitle className="text-3xl font-bold flex items-center gap-3 text-white">
                      <div className="p-2 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/30">
                        <DollarSign className="w-7 h-7 text-white" />
                      </div>
                      Budget Breakdown
                    </DialogTitle>
                    <DialogDescription className="text-slate-400 text-base mt-2">
                      Comprehensive expense planning for {selectedBudgetPlace.name}
                    </DialogDescription>
                  </div>
                </div>
              </DialogHeader>
              
              <ScrollArea className="max-h-[70vh] pr-4">
                <div className="space-y-6">
                  {/* Location Preview Card */}
                  <div className="relative w-full h-64 rounded-2xl overflow-hidden border-2 border-emerald-500/20 shadow-2xl group">
                    <img 
                      src={selectedBudgetPlace.imageUrl} 
                      alt={selectedBudgetPlace.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent" />
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 to-teal-500/10" />
                    
                    {/* Floating Type Badge */}
                    <div className="absolute top-4 right-4 px-4 py-2 rounded-full bg-slate-900/90 backdrop-blur-md border-2 border-emerald-500/50 shadow-lg">
                      <span className="text-sm font-bold text-emerald-400">{selectedBudgetPlace.type}</span>
                    </div>
                    
                    {/* Location Title Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 p-6">
                      <h3 className="text-3xl font-bold text-white mb-2">{selectedBudgetPlace.name}</h3>
                      <p className="text-emerald-400 font-semibold text-sm uppercase tracking-wider">Per Person Budget Estimate</p>
                    </div>
                  </div>
                  
                  {/* Enhanced Budget Details */}
                  <div className="bg-gradient-to-br from-emerald-500/10 via-teal-500/10 to-cyan-500/10 border-2 border-emerald-500/30 rounded-2xl overflow-hidden shadow-2xl">
                    {(() => {
                      const expenseData = generateExpenseData(selectedBudgetPlace.name);
                      const total = expenseData.reduce((sum, item) => sum + item.value, 0);
                      const COLORS = ['#06b6d4', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'];
                      
                      return (
                        <>
                          {/* Chart Section */}
                          <div className="bg-slate-900/50 backdrop-blur-sm p-8">
                            <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                              Expense Distribution
                            </h4>
                            <div className="h-[320px]">
                              <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                  <Pie
                                    data={expenseData}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={true}
                                    label={({ name, percent, value }) => `${name}: ₹${value} (${(percent * 100).toFixed(0)}%)`}
                                    outerRadius={120}
                                    fill="#8884d8"
                                    dataKey="value"
                                    strokeWidth={3}
                                    stroke="#0f172a"
                                  >
                                    {expenseData.map((entry, i) => (
                                      <Cell key={`cell-${i}`} fill={COLORS[i % COLORS.length]} />
                                    ))}
                                  </Pie>
                                  <Tooltip 
                                    contentStyle={{ 
                                      backgroundColor: 'rgba(15, 23, 42, 0.98)', 
                                      border: '2px solid rgba(16, 185, 129, 0.3)',
                                      borderRadius: '12px',
                                      color: '#fff',
                                      padding: '12px',
                                      fontWeight: 'bold'
                                    }}
                                    formatter={(value: number) => [`₹${value}`, 'Amount']}
                                  />
                                </PieChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                          
                          {/* Detailed Breakdown */}
                          <div className="p-8 bg-slate-950/50">
                            <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                              Detailed Breakdown
                            </h4>
                            <div className="space-y-4">
                              {expenseData.map((item, i) => (
                                <div 
                                  key={i} 
                                  className="group relative overflow-hidden bg-gradient-to-r from-slate-900/80 to-slate-800/80 rounded-xl p-5 border-2 border-slate-700/50 hover:border-emerald-500/50 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg hover:shadow-emerald-500/20"
                                  style={{
                                    backgroundImage: `linear-gradient(to right, ${COLORS[i % COLORS.length]}10, transparent)`
                                  }}
                                >
                                  {/* Background accent */}
                                  <div 
                                    className="absolute top-0 left-0 w-1 h-full transition-all duration-300 group-hover:w-2"
                                    style={{ backgroundColor: COLORS[i % COLORS.length] }}
                                  />
                                  
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-4">
                                      {/* Icon Badge */}
                                      <div 
                                        className="w-12 h-12 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300"
                                        style={{ backgroundColor: COLORS[i % COLORS.length] + '20', borderColor: COLORS[i % COLORS.length] + '40' }}
                                      >
                                        {item.name === 'Stay' && <Home className="w-6 h-6" style={{ color: COLORS[0] }} />}
                                        {item.name === 'Food' && <Utensils className="w-6 h-6" style={{ color: COLORS[1] }} />}
                                        {item.name === 'Transport' && <Car className="w-6 h-6" style={{ color: COLORS[2] }} />}
                                        {item.name === 'Activities' && <Camera className="w-6 h-6" style={{ color: COLORS[3] }} />}
                                        {item.name === 'Misc' && <Wallet className="w-6 h-6" style={{ color: COLORS[4] }} />}
                                      </div>
                                      
                                      <div>
                                        <p className="text-white font-bold text-lg mb-1">{item.name}</p>
                                        <p className="text-slate-400 text-xs">
                                          {item.name === 'Stay' && 'Accommodation & Lodging'}
                                          {item.name === 'Food' && 'Meals & Dining'}
                                          {item.name === 'Transport' && 'Local Travel & Transfers'}
                                          {item.name === 'Activities' && 'Tours & Experiences'}
                                          {item.name === 'Misc' && 'Shopping & Extras'}
                                        </p>
                                      </div>
                                    </div>
                                    
                                    {/* Price */}
                                    <div className="text-right">
                                      <p className="text-2xl font-bold text-white">₹{item.value}</p>
                                      <p className="text-xs text-slate-400">{((item.value / total) * 100).toFixed(1)}% of total</p>
                                    </div>
                                  </div>
                                </div>
                              ))}
                              
                              {/* Total Budget Card */}
                              <div className="relative overflow-hidden bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-6 shadow-2xl shadow-emerald-500/30 border-2 border-emerald-400/50 mt-6">
                                {/* Animated background effect */}
                                <div className="absolute inset-0 bg-gradient-to-r from-emerald-400/0 via-emerald-400/20 to-emerald-400/0 animate-pulse" />
                                
                                <div className="relative flex items-center justify-between">
                                  <div className="flex items-center gap-4">
                                    <div className="w-14 h-14 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                                      <DollarSign className="w-8 h-8 text-white" />
                                    </div>
                                    <div>
                                      <p className="text-white/80 text-sm font-medium uppercase tracking-wider">Total Estimated Budget</p>
                                      <p className="text-white text-xs mt-1">Per person for complete experience</p>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <p className="text-4xl font-black text-white drop-shadow-lg">₹{total}</p>
                                    <p className="text-emerald-100 text-sm font-semibold mt-1">All Inclusive</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Tips & Info Section */}
                          <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-t-2 border-cyan-500/20 p-6">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                                  <span className="text-cyan-400 text-lg">💡</span>
                                </div>
                                <div>
                                  <p className="text-white font-semibold text-sm mb-1">Best Season</p>
                                  <p className="text-slate-400 text-xs">October to March offers pleasant weather</p>
                                </div>
                              </div>
                              <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                                  <span className="text-purple-400 text-lg">⏱️</span>
                                </div>
                                <div>
                                  <p className="text-white font-semibold text-sm mb-1">Ideal Duration</p>
                                  <p className="text-slate-400 text-xs">2-3 days recommended for full experience</p>
                                </div>
                              </div>
                              <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                                  <span className="text-emerald-400 text-lg">💰</span>
                                </div>
                                <div>
                                  <p className="text-white font-semibold text-sm mb-1">Budget Tip</p>
                                  <p className="text-slate-400 text-xs">Book accommodations early for better rates</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                  
                  {/* Disclaimer */}
                  <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-4 flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-amber-400 text-xs">ℹ️</span>
                    </div>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      <span className="text-amber-400 font-semibold">Note:</span> Prices are approximate estimates and may vary based on season, availability, and personal preferences. Actual costs may differ. We recommend booking in advance during peak tourist season for better rates and availability.
                    </p>
                  </div>
                </div>
              </ScrollArea>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Login/Signup Modal */}
      <Dialog open={isLoginOpen} onOpenChange={setIsLoginOpen}>
        <DialogContent className="max-w-md bg-slate-950/95 backdrop-blur-xl border border-cyan-500/20 shadow-2xl shadow-cyan-500/20">
          <DialogHeader>
            <DialogTitle className="text-3xl font-bold text-center bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
              {isSignUp ? 'Join IAGI Warriors' : 'Welcome Back'}
            </DialogTitle>
            <DialogDescription className="text-center text-slate-400">
              {isSignUp ? 'Create your account to start planning amazing trips' : 'Login to continue your journey'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 mt-6">
            {/* Animated orbs background */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-lg">
              <motion.div
                className="absolute top-0 left-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3],
                }}
                transition={{ duration: 4, repeat: Infinity }}
              />
              <motion.div
                className="absolute bottom-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl"
                animate={{
                  scale: [1.2, 1, 1.2],
                  opacity: [0.5, 0.3, 0.5],
                }}
                transition={{ duration: 4, repeat: Infinity, delay: 2 }}
              />
            </div>

            <form onSubmit={isSignUp ? handleSignUp : handleLogin} className="space-y-4 relative z-10">
              {isSignUp && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-300">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                    <input
                      type="text"
                      value={signUpName}
                      onChange={(e) => setSignUpName(e.target.value)}
                      className="w-full pl-11 pr-4 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white placeholder:text-slate-500 focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
                      placeholder="Enter your full name"
                      required
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white placeholder:text-slate-500 focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
                    placeholder="your@email.com"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full pl-11 pr-12 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white placeholder:text-slate-500 focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
                    placeholder="Enter your password"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {!isSignUp && (
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-cyan-500/20"
                    />
                    <span className="text-sm text-slate-400">Remember me</span>
                  </label>
                  <button type="button" className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">
                    Forgot password?
                  </button>
                </div>
              )}

              <Button
                type="submit"
                className="w-full h-12 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold rounded-xl shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 transition-all"
              >
                {isSignUp ? 'Create Account' : 'Login'}
              </Button>
            </form>

            <div className="relative z-10">
              <div className="relative flex items-center justify-center">
                <div className="border-t border-slate-700/50 w-full absolute" />
                <span className="bg-slate-950 px-4 text-sm text-slate-500 relative">Or continue with</span>
              </div>

              <div className="grid grid-cols-2 gap-3 mt-4">
                <button
                  type="button"
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-slate-900/50 border border-slate-700/50 rounded-xl hover:bg-slate-800/50 hover:border-slate-600/50 transition-all group"
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  <span className="text-sm text-slate-300">Google</span>
                </button>
                <button
                  type="button"
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-slate-900/50 border border-slate-700/50 rounded-xl hover:bg-slate-800/50 hover:border-slate-600/50 transition-all group"
                >
                  <Facebook className="w-5 h-5 text-blue-500" fill="#1877F2" />
                  <span className="text-sm text-slate-300">Facebook</span>
                </button>
              </div>
            </div>

            <div className="text-center text-sm text-slate-400 relative z-10">
              {isSignUp ? (
                <>
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setIsSignUp(false)}
                    className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors"
                  >
                    Login here
                  </button>
                </>
              ) : (
                <>
                  Don't have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setIsSignUp(true)}
                    className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors"
                  >
                    Sign up
                  </button>
                </>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Book Now Modal */}
      <Dialog open={isBookingOpen} onOpenChange={setIsBookingOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-slate-950/95 backdrop-blur-xl border border-purple-500/20 shadow-2xl shadow-purple-500/20">
          <DialogHeader>
            <DialogTitle className="text-4xl font-bold text-center bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
              Book Your Journey
            </DialogTitle>
            <DialogDescription className="text-center text-slate-400 text-base">
              Plan your perfect trip across India with ease
            </DialogDescription>
            
            {/* Step Indicator */}
            <div className="flex items-center justify-center gap-3 mt-6">
              {[
                { step: 1, label: 'Transport' },
                { step: 2, label: 'Journey' },
                { step: 3, label: 'Details' },
                { step: 4, label: 'Review' }
              ].map((item, index) => (
                <div key={item.step} className="flex items-center">
                  <div className="flex flex-col items-center">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300 ${
                      bookingStep === item.step 
                        ? 'bg-gradient-to-br from-purple-500 to-pink-500 text-white scale-110 shadow-lg shadow-purple-500/50' 
                        : bookingStep > item.step
                        ? 'bg-gradient-to-br from-green-500 to-emerald-500 text-white'
                        : 'bg-slate-800 text-slate-500 border border-slate-700'
                    }`}>
                      {bookingStep > item.step ? <Check className="w-5 h-5" /> : item.step}
                    </div>
                    <span className={`text-xs mt-1 font-medium ${
                      bookingStep === item.step ? 'text-purple-400' : bookingStep > item.step ? 'text-emerald-400' : 'text-slate-500'
                    }`}>
                      {item.label}
                    </span>
                  </div>
                  {index < 3 && (
                    <div className={`w-12 h-0.5 mb-5 mx-2 transition-all duration-300 ${
                      bookingStep > item.step ? 'bg-gradient-to-r from-green-500 to-emerald-500' : 'bg-slate-700'
                    }`} />
                  )}
                </div>
              ))}
            </div>
          </DialogHeader>

          <div className="relative">
            {/* Animated background orbs */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-lg">
              <motion.div
                className="absolute top-0 left-0 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl"
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.3, 0.6, 0.3],
                }}
                transition={{ duration: 5, repeat: Infinity }}
              />
              <motion.div
                className="absolute bottom-0 right-0 w-72 h-72 bg-pink-500/10 rounded-full blur-3xl"
                animate={{
                  scale: [1.3, 1, 1.3],
                  opacity: [0.6, 0.3, 0.6],
                }}
                transition={{ duration: 5, repeat: Infinity, delay: 2.5 }}
              />
            </div>

            <form onSubmit={handleBookingSubmit} className="space-y-6 relative z-10 mt-6">
              {/* STEP 1: Mode of Transport Selection */}
              {bookingStep === 1 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-3"
                >
                <label className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  Mode of Transport
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                  {[
                    { value: 'flight', icon: Plane, label: 'Flight', color: 'from-blue-500 to-cyan-500' },
                    { value: 'train', icon: Train, label: 'Train', color: 'from-green-500 to-emerald-500' },
                    { value: 'bus', icon: Bus, label: 'Bus', color: 'from-orange-500 to-yellow-500' },
                    { value: 'car', icon: CarFront, label: 'Car/Taxi', color: 'from-purple-500 to-pink-500' },
                    { value: 'bike', icon: Bike, label: 'Bike', color: 'from-red-500 to-rose-500' },
                  ].map((mode) => {
                    const Icon = mode.icon;
                    return (
                      <button
                        key={mode.value}
                        type="button"
                        onClick={() => setTransportMode(mode.value)}
                        className={`relative p-4 rounded-xl border-2 transition-all duration-300 ${
                          transportMode === mode.value
                            ? `bg-gradient-to-br ${mode.color} border-white/50 shadow-lg scale-105`
                            : 'bg-slate-900/50 border-slate-700/50 hover:border-slate-600/50'
                        }`}
                      >
                        <div className="flex flex-col items-center gap-2">
                          <Icon className={`w-8 h-8 ${transportMode === mode.value ? 'text-white' : 'text-slate-400'}`} />
                          <span className={`text-xs font-semibold ${transportMode === mode.value ? 'text-white' : 'text-slate-400'}`}>
                            {mode.label}
                          </span>
                        </div>
                        {transportMode === mode.value && (
                          <motion.div
                            layoutId="activeTransport"
                            className="absolute inset-0 rounded-xl border-2 border-white/30"
                            transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                          />
                        )}
                      </button>
                    );
                  })}
                </div>
                </motion.div>
              )}

              {/* STEP 2: From & To Destinations & Dates */}
              {bookingStep === 2 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
              {/* From & To Destinations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-purple-400" />
                    From Destination
                  </label>
                  <select
                    value={fromDestination}
                    onChange={(e) => setFromDestination(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white focus:border-purple-500/50 focus:outline-none focus:ring-2 focus:ring-purple-500/20 transition-all"
                    required
                  >
                    <option value="">Select starting point</option>
                    {indianStates.map((state) => (
                      <option key={state.name} value={state.name}>
                        {state.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                    <Plane className="w-4 h-4 text-pink-400" />
                    To Destination
                  </label>
                  <select
                    value={toDestination}
                    onChange={(e) => setToDestination(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white focus:border-pink-500/50 focus:outline-none focus:ring-2 focus:ring-pink-500/20 transition-all"
                    required
                  >
                    <option value="">Select destination</option>
                    {indianStates.map((state) => (
                      <option key={state.name} value={state.name}>
                        {state.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Date Selection */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-cyan-400" />
                    Departure Date
                  </label>
                  <input
                    type="date"
                    value={departureDate}
                    onChange={(e) => setDepartureDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all [&::-webkit-calendar-picker-indicator]:filter [&::-webkit-calendar-picker-indicator]:invert"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-400" />
                    Return Date
                  </label>
                  <input
                    type="date"
                    value={returnDate}
                    onChange={(e) => setReturnDate(e.target.value)}
                    min={departureDate || new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white focus:border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all [&::-webkit-calendar-picker-indicator]:filter [&::-webkit-calendar-picker-indicator]:invert"
                    required
                  />
                </div>
              </div>

              {/* Travelers & Class */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                    <Users className="w-4 h-4 text-orange-400" />
                    Number of Travelers
                  </label>
                  <input
                    type="number"
                    value={travelers}
                    onChange={(e) => setTravelers(Number(e.target.value))}
                    min="1"
                    max="20"
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white focus:border-orange-500/50 focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-yellow-400" />
                    Travel Class
                  </label>
                  <select
                    value={travelClass}
                    onChange={(e) => setTravelClass(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700/50 rounded-xl text-white focus:border-yellow-500/50 focus:outline-none focus:ring-2 focus:ring-yellow-500/20 transition-all"
                  >
                    <option value="economy">Economy</option>
                    <option value="premium">Premium Economy</option>
                    <option value="business">Business Class</option>
                    <option value="first">First Class</option>
                  </select>
                </div>
              </div>
              </motion.div>
              )}

              {/* STEP 3: Transport-Specific Fields */}
              {bookingStep === 3 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
              <AnimatePresence mode="wait">
                {transportMode === 'flight' && (
                  <motion.div
                    key="flight-fields"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-4 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/30 rounded-2xl p-6"
                  >
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Plane className="w-5 h-5 text-cyan-400" />
                      Flight Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Flight Type</label>
                        <select
                          value={flightType}
                          onChange={(e) => setFlightType(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        >
                          <option value="roundtrip">Round Trip</option>
                          <option value="oneway">One Way</option>
                          <option value="multicity">Multi-City</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Cabin Class</label>
                        <select
                          value={cabinClass}
                          onChange={(e) => setCabinClass(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        >
                          <option value="economy">Economy</option>
                          <option value="premium-economy">Premium Economy</option>
                          <option value="business">Business</option>
                          <option value="first">First Class</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Preferred Airline</label>
                        <select
                          value={preferredAirline}
                          onChange={(e) => setPreferredAirline(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
                        >
                          <option value="">No Preference</option>
                          <option value="indigo">IndiGo</option>
                          <option value="air-india">Air India</option>
                          <option value="spicejet">SpiceJet</option>
                          <option value="vistara">Vistara</option>
                          <option value="airindia-express">Air India Express</option>
                          <option value="akasa">Akasa Air</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 flex items-start gap-2">
                      <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-slate-300">Baggage allowance varies by airline. Check-in baggage typically 15-30kg, cabin 7kg.</p>
                    </div>
                  </motion.div>
                )}

                {transportMode === 'train' && (
                  <motion.div
                    key="train-fields"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-4 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-2xl p-6"
                  >
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Train className="w-5 h-5 text-emerald-400" />
                      Train Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Train Class</label>
                        <select
                          value={trainClass}
                          onChange={(e) => setTrainClass(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                        >
                          <option value="sleeper">Sleeper (SL)</option>
                          <option value="3ac">3-Tier AC (3A)</option>
                          <option value="2ac">2-Tier AC (2A)</option>
                          <option value="1ac">1st Class AC (1A)</option>
                          <option value="chair-car">Chair Car (CC)</option>
                          <option value="executive">Executive Class (EC)</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Berth Preference</label>
                        <select
                          value={berthPreference}
                          onChange={(e) => setBerthPreference(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                        >
                          <option value="lower">Lower Berth</option>
                          <option value="middle">Middle Berth</option>
                          <option value="upper">Upper Berth</option>
                          <option value="side-lower">Side Lower</option>
                          <option value="side-upper">Side Upper</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Train Type</label>
                        <select
                          value={trainType}
                          onChange={(e) => setTrainType(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-emerald-500/50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                        >
                          <option value="express">Express</option>
                          <option value="superfast">Superfast</option>
                          <option value="rajdhani">Rajdhani</option>
                          <option value="shatabdi">Shatabdi</option>
                          <option value="vande-bharat">Vande Bharat</option>
                          <option value="duronto">Duronto</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 flex items-start gap-2">
                      <Info className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-slate-300">Carry valid ID proof. Meals included in Rajdhani/Shatabdi. Book early for berth preference.</p>
                    </div>
                  </motion.div>
                )}

                {transportMode === 'bus' && (
                  <motion.div
                    key="bus-fields"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-4 bg-gradient-to-r from-orange-500/10 to-yellow-500/10 border border-orange-500/30 rounded-2xl p-6"
                  >
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Bus className="w-5 h-5 text-orange-400" />
                      Bus Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Bus Type</label>
                        <select
                          value={busType}
                          onChange={(e) => setBusType(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-orange-500/50 focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all"
                        >
                          <option value="sleeper">Sleeper</option>
                          <option value="semi-sleeper">Semi-Sleeper</option>
                          <option value="seater">Seater</option>
                          <option value="volvo">Volvo</option>
                          <option value="multi-axle">Multi-Axle</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Seat Type</label>
                        <select
                          value={seatType}
                          onChange={(e) => setSeatType(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-orange-500/50 focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all"
                        >
                          <option value="window">Window</option>
                          <option value="aisle">Aisle</option>
                          <option value="any">Any Seat</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">AC Preference</label>
                        <select
                          value={acPreference}
                          onChange={(e) => setAcPreference(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-orange-500/50 focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all"
                        >
                          <option value="ac">AC</option>
                          <option value="non-ac">Non-AC</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3 flex items-start gap-2">
                      <Info className="w-4 h-4 text-orange-400 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-slate-300">Blankets provided in sleeper buses. Carry snacks for long journeys. Check pickup points in advance.</p>
                    </div>
                    
                    {/* View Route Map Button */}
                    {fromDestination && toDestination && (
                      <button
                        type="button"
                        onClick={() => setShowRouteMap(!showRouteMap)}
                        className="w-full py-3 bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
                      >
                        <Map className="w-5 h-5" />
                        {showRouteMap ? 'Hide Route Map' : 'View Route Map & Live Tracking'}
                      </button>
                    )}
                    
                    {/* Route Map */}
                    <AnimatePresence>
                      {showRouteMap && fromDestination && toDestination && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <RouteMap 
                            fromState={fromDestination} 
                            toState={toDestination} 
                            transportMode="bus" 
                          />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                )}

                {transportMode === 'car' && (
                  <motion.div
                    key="car-fields"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-2xl p-6"
                  >
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <CarFront className="w-5 h-5 text-purple-400" />
                      Car/Taxi Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Car Type</label>
                        <select
                          value={carType}
                          onChange={(e) => setCarType(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-purple-500/50 focus:outline-none focus:ring-2 focus:ring-purple-500/20 transition-all"
                        >
                          <option value="sedan">Sedan (4 Seater)</option>
                          <option value="suv">SUV (7 Seater)</option>
                          <option value="luxury">Luxury Car</option>
                          <option value="mini">Mini/Hatchback</option>
                          <option value="tempo">Tempo Traveller (12+ Seater)</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Driver Option</label>
                        <select
                          value={withDriver ? 'with' : 'self'}
                          onChange={(e) => setWithDriver(e.target.value === 'with')}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-purple-500/50 focus:outline-none focus:ring-2 focus:ring-purple-500/20 transition-all"
                        >
                          <option value="with">With Driver</option>
                          <option value="self">Self Drive</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Fuel Type</label>
                        <select
                          value={fuelType}
                          onChange={(e) => setFuelType(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-purple-500/50 focus:outline-none focus:ring-2 focus:ring-purple-500/20 transition-all"
                        >
                          <option value="petrol">Petrol</option>
                          <option value="diesel">Diesel</option>
                          <option value="cng">CNG</option>
                          <option value="electric">Electric</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-3 flex items-start gap-2">
                      <Info className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-slate-300">Self-drive requires valid driving license. Fuel costs extra. Driver allowance ₹300-500/day for outstation.</p>
                    </div>
                    
                    {/* View Route Map Button */}
                    {fromDestination && toDestination && (
                      <button
                        type="button"
                        onClick={() => setShowRouteMap(!showRouteMap)}
                        className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
                      >
                        <Map className="w-5 h-5" />
                        {showRouteMap ? 'Hide Route Map' : 'View Route Map & Live Tracking'}
                      </button>
                    )}
                    
                    {/* Route Map */}
                    <AnimatePresence>
                      {showRouteMap && fromDestination && toDestination && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <RouteMap 
                            fromState={fromDestination} 
                            toState={toDestination} 
                            transportMode="car" 
                          />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                )}

                {transportMode === 'bike' && (
                  <motion.div
                    key="bike-fields"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-4 bg-gradient-to-r from-red-500/10 to-rose-500/10 border border-red-500/30 rounded-2xl p-6"
                  >
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Bike className="w-5 h-5 text-red-400" />
                      Bike Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Bike Type</label>
                        <select
                          value={bikeType}
                          onChange={(e) => setBikeType(e.target.value)}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-red-500/50 focus:outline-none focus:ring-2 focus:ring-red-500/20 transition-all"
                        >
                          <option value="standard">Standard (100-150cc)</option>
                          <option value="sports">Sports Bike (150-300cc)</option>
                          <option value="cruiser">Cruiser (300cc+)</option>
                          <option value="scooter">Scooter</option>
                          <option value="adventure">Adventure Bike</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Helmet Required</label>
                        <select
                          value={helmetRequired ? 'yes' : 'no'}
                          onChange={(e) => setHelmetRequired(e.target.value === 'yes')}
                          className="w-full px-4 py-2.5 bg-slate-900/50 border border-slate-700/50 rounded-lg text-white text-sm focus:border-red-500/50 focus:outline-none focus:ring-2 focus:ring-red-500/20 transition-all"
                        >
                          <option value="yes">Yes (2 Helmets)</option>
                          <option value="no">No (Own Helmet)</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 flex items-start gap-2">
                      <Info className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-slate-300">Valid driving license mandatory. Helmet compulsory by law. Check bike condition before starting journey.</p>
                    </div>
                    
                    {/* View Route Map Button */}
                    {fromDestination && toDestination && (
                      <button
                        type="button"
                        onClick={() => setShowRouteMap(!showRouteMap)}
                        className="w-full py-3 bg-gradient-to-r from-red-500 to-rose-500 hover:from-red-600 hover:to-rose-600 text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
                      >
                        <Map className="w-5 h-5" />
                        {showRouteMap ? 'Hide Route Map' : 'View Route Map & Live Tracking'}
                      </button>
                    )}
                    
                    {/* Route Map */}
                    <AnimatePresence>
                      {showRouteMap && fromDestination && toDestination && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <RouteMap 
                            fromState={fromDestination} 
                            toState={toDestination} 
                            transportMode="bike" 
                          />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                )}
              </AnimatePresence>
              </motion.div>
              )}

              {/* STEP 4: Review & Summary */}
              {bookingStep === 4 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
              {/* Trip Summary Card */}
              {fromDestination && toDestination && departureDate && returnDate && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-cyan-500/10 border border-purple-500/30 rounded-2xl p-6 backdrop-blur-sm"
                >
                  <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-yellow-400" />
                    Trip Summary
                  </h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-slate-400">Journey</p>
                      <p className="text-white font-semibold">{fromDestination} → {toDestination}</p>
                    </div>
                    <div>
                      <p className="text-slate-400">Duration</p>
                      <p className="text-white font-semibold">
                        {Math.ceil((new Date(returnDate).getTime() - new Date(departureDate).getTime()) / (1000 * 60 * 60 * 24))} days
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-400">Transport Mode</p>
                      <p className="text-white font-semibold capitalize flex items-center gap-2">
                        {transportMode === 'flight' && <Plane className="w-4 h-4 text-cyan-400" />}
                        {transportMode === 'train' && <Train className="w-4 h-4 text-emerald-400" />}
                        {transportMode === 'bus' && <Bus className="w-4 h-4 text-orange-400" />}
                        {transportMode === 'car' && <CarFront className="w-4 h-4 text-purple-400" />}
                        {transportMode === 'bike' && <Bike className="w-4 h-4 text-red-400" />}
                        {transportMode}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-400">Travelers</p>
                      <p className="text-white font-semibold">{travelers} {travelers === 1 ? 'person' : 'people'}</p>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Additional Info */}
              <div className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-4 flex items-start gap-3">
                <div className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-cyan-400 text-xs">ℹ️</span>
                </div>
                <p className="text-slate-400 text-xs leading-relaxed">
                  <span className="text-cyan-400 font-semibold">Note:</span> This booking form will help us create a personalized itinerary for your trip. Our AI travel assistant will reach out with recommendations based on your preferences.
                </p>
              </div>
              </motion.div>
              )}

              {/* Navigation Buttons */}
              <div className="flex gap-4 pt-4 border-t border-slate-700/50">
                {bookingStep > 1 ? (
                  <Button
                    type="button"
                    onClick={handleBookingBack}
                    variant="outline"
                    className="h-12 px-6 border-slate-700 text-slate-300 hover:bg-slate-800/50 flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </Button>
                ) : (
                  <Button
                    type="button"
                    onClick={() => setIsBookingOpen(false)}
                    variant="outline"
                    className="h-12 px-6 border-slate-700 text-slate-300 hover:bg-slate-800/50"
                  >
                    Cancel
                  </Button>
                )}

                {bookingStep < 4 ? (
                  <Button
                    type="button"
                    onClick={handleBookingNext}
                    className="flex-1 h-12 bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-600 hover:from-purple-700 hover:via-pink-700 hover:to-cyan-700 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-all flex items-center justify-center gap-2"
                  >
                    Next Step
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    className="flex-1 h-12 bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 hover:from-green-700 hover:via-emerald-700 hover:to-teal-700 text-white font-semibold rounded-xl shadow-lg shadow-green-500/30 hover:shadow-green-500/50 transition-all flex items-center justify-center gap-2"
                  >
                    <Check className="w-5 h-5" />
                    Confirm Booking
                  </Button>
                )}
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

const features = [
  {
    title: "Personalized Trips",
    description: "Tailored itineraries based on your interests & style.",
    icon: Map,
    gradient: "from-pink-500 to-rose-500",
    cardGradient: "from-pink-500 to-rose-500",
    borderColor: "border-pink-500",
    shadowColor: "shadow-pink-500"
  },
  {
    title: "Budget Smart",
    description: "Optimized plans that respect your budget limits.",
    icon: Wallet,
    gradient: "from-emerald-500 to-green-500",
    cardGradient: "from-emerald-500 to-green-500",
    borderColor: "border-emerald-500",
    shadowColor: "shadow-emerald-500"
  },
  {
    title: "Time Optimized",
    description: "Best routes with maximum experience in minimum time.",
    icon: Clock,
    gradient: "from-amber-500 to-orange-500",
    cardGradient: "from-amber-500 to-orange-500",
    borderColor: "border-amber-500",
    shadowColor: "shadow-amber-500"
  },
  {
    title: "AI Powered",
    description: "Smart recommendations that adapt in real time.",
    icon: BrainCircuit,
    gradient: "from-cyan-500 to-blue-500",
    cardGradient: "from-cyan-500 to-blue-500",
    borderColor: "border-cyan-500",
    shadowColor: "shadow-cyan-500"
  }
];

// Function to generate expense data for a given place
const generateExpenseData = (placeName: string): { name: string, value: number }[] => {
  // Create a simple hash from place name to get consistent but varied values
  const hash = placeName.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  
  // Base values with variations
  const stayBase = 1200 + (hash % 800);
  const foodBase = 400 + (hash % 400);
  const transportBase = 250 + (hash % 250);
  const activitiesBase = 300 + (hash % 500);
  const miscBase = 150 + (hash % 200);
  
  return [
    { name: 'Stay', value: stayBase },
    { name: 'Food', value: foodBase },
    { name: 'Transport', value: transportBase },
    { name: 'Activities', value: activitiesBase },
    { name: 'Misc', value: miscBase }
  ];
};