// Comprehensive district-based tourist places for all 29 Indian states
export interface TouristPlace {
  name: string;
  description: string;
  type: string;
  imageUrl: string;
}

export interface District {
  name: string;
  places: TouristPlace[];
}

export const districtData: { [state: string]: District[] } = {
  "Karnataka": [
    {
      name: "Bangalore Urban",
      places: [
        { name: "Lalbagh Botanical Garden", description: "Historic 240-acre botanical garden with glass house & rare plant species", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1675589412450-571c4a5afe6e?w=1080" },
        { name: "Bangalore Palace", description: "Tudor-style palace with elegant architecture & royal artifacts", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1675589412450-571c4a5afe6e?w=1080" },
        { name: "Cubbon Park", description: "Green lung of Bangalore with Victorian buildings & walking trails", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1675589412450-571c4a5afe6e?w=1080" },
        { name: "ISKCON Temple", description: "Modern spiritual complex with stunning architecture & cultural programs", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1675589412450-571c4a5afe6e?w=1080" },
        { name: "Vidhana Soudha", description: "Imposing legislative building with neo-Dravidian architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1675589412450-571c4a5afe6e?w=1080" }
      ]
    },
    {
      name: "Mysore",
      places: [
        { name: "Mysore Palace", description: "Royal palace with stunning Indo-Saracenic architecture & golden throne", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1637075735042-727375ffcb6a?w=1080" },
        { name: "Chamundi Hills", description: "Sacred hill with ancient temple & panoramic city views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1637075735042-727375ffcb6a?w=1080" },
        { name: "Brindavan Gardens", description: "Terraced gardens with musical fountain show & colorful lights", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1637075735042-727375ffcb6a?w=1080" },
        { name: "Mysore Zoo", description: "One of India's oldest zoos with diverse wildlife collection", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1637075735042-727375ffcb6a?w=1080" },
        { name: "St. Philomena's Cathedral", description: "Neo-Gothic church with twin spires & stained glass windows", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1637075735042-727375ffcb6a?w=1080" }
      ]
    },
    {
      name: "Kodagu (Coorg)",
      places: [
        { name: "Abbey Falls", description: "Spectacular waterfall amid coffee estates & spice plantations", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" },
        { name: "Raja's Seat", description: "Sunset viewpoint with landscaped gardens & valley views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" },
        { name: "Dubare Elephant Camp", description: "Interactive elephant bathing & feeding experience on riverbank", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" },
        { name: "Talakaveri", description: "Sacred birthplace of River Kaveri with temple & mountain views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" },
        { name: "Nagarhole National Park", description: "Tiger reserve with rich wildlife & safari experiences", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" }
      ]
    },
    {
      name: "Ballari (Hampi)",
      places: [
        { name: "Virupaksha Temple", description: "Ancient Shiva temple still in active worship since 7th century", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1689946727792-344fced11ea2?w=1080" },
        { name: "Vittala Temple Complex", description: "Famous stone chariot & musical pillars of Hampi", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1689946727792-344fced11ea2?w=1080" },
        { name: "Lotus Mahal", description: "Indo-Islamic palace with lotus-bud architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1689946727792-344fced11ea2?w=1080" },
        { name: "Matanga Hill", description: "Sunrise viewpoint overlooking Hampi's boulder landscape", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1689946727792-344fced11ea2?w=1080" },
        { name: "Elephant Stables", description: "Royal elephant housing with 11 domed chambers", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1689946727792-344fced11ea2?w=1080" }
      ]
    },
    {
      name: "Udupi",
      places: [
        { name: "Krishna Temple", description: "Famous pilgrimage site with unique idol worship tradition", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" },
        { name: "Malpe Beach", description: "Pristine beach with water sports & St. Mary's Island access", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" },
        { name: "St. Mary's Island", description: "Geological wonder with hexagonal basaltic rock formations", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" },
        { name: "Kaup Beach & Lighthouse", description: "Scenic lighthouse with panoramic coastal views", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1694537623159-52f5c5a98029?w=1080" }
      ]
    }
  ],

  "Kerala": [
    {
      name: "Idukki",
      places: [
        { name: "Munnar Tea Gardens", description: "Rolling hills covered with lush tea plantations & cool climate", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1625029303222-029538479161?w=1080" },
        { name: "Eravikulam National Park", description: "Home to endangered Nilgiri Tahr with blooming Neelakurinji flowers", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1625029303222-029538479161?w=1080" },
        { name: "Mattupetty Dam", description: "Scenic reservoir perfect for boating amid mountains", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1625029303222-029538479161?w=1080" },
        { name: "Top Station", description: "Highest point with breathtaking Western Ghats views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1625029303222-029538479161?w=1080" },
        { name: "Periyar Wildlife Sanctuary", description: "Thekkady elephant & tiger reserve with boat safaris", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1709730705218-3ccc27971489?w=1080" }
      ]
    },
    {
      name: "Alappuzha",
      places: [
        { name: "Alleppey Backwaters", description: "Tranquil houseboat cruises through palm-fringed canals", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1707893013488-51672ef83425?w=1080" },
        { name: "Alappuzha Beach", description: "Pristine beach with historic pier & coastal views", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1707893013488-51672ef83425?w=1080" },
        { name: "Kumarakom Bird Sanctuary", description: "Migratory bird paradise on Vembanad Lake shores", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1707893013488-51672ef83425?w=1080" },
        { name: "Marari Beach", description: "Secluded beach perfect for peaceful relaxation", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1707893013488-51672ef83425?w=1080" },
        { name: "Punnamada Lake", description: "Famous venue for Nehru Trophy Boat Race", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1707893013488-51672ef83425?w=1080" }
      ]
    },
    {
      name: "Ernakulam",
      places: [
        { name: "Fort Kochi", description: "Historic port city with colonial architecture & Chinese nets", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1642667670006-6b3059ccf96d?w=1080" },
        { name: "Mattancherry Palace", description: "Dutch Palace with exquisite Kerala murals & royal artifacts", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1642667670006-6b3059ccf96d?w=1080" },
        { name: "Marine Drive", description: "Scenic promenade along Kochi backwaters perfect for evening walks", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1642667670006-6b3059ccf96d?w=1080" },
        { name: "Jewish Synagogue", description: "Oldest active synagogue in Commonwealth with Belgian chandeliers", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1642667670006-6b3059ccf96d?w=1080" },
        { name: "Cherai Beach", description: "Golden sand beach with backwaters on one side", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1642667670006-6b3059ccf96d?w=1080" }
      ]
    },
    {
      name: "Thiruvananthapuram",
      places: [
        { name: "Padmanabhaswamy Temple", description: "Ancient Vishnu temple with immense treasure vault", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1625029303222-029538479161?w=1080" },
        { name: "Kovalam Beach", description: "Crescent-shaped beach with lighthouse & water sports", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1625029303222-029538479161?w=1080" },
        { name: "Napier Museum", description: "Indo-Saracenic museum with art & archaeological collections", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1625029303222-029538479161?w=1080" },
        { name: "Veli Tourist Village", description: "Lagoon meeting sea with floating bridge & gardens", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1625029303222-029538479161?w=1080" }
      ]
    },
    {
      name: "Wayanad",
      places: [
        { name: "Edakkal Caves", description: "Prehistoric rock shelter with ancient petroglyphs", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1709730705218-3ccc27971489?w=1080" },
        { name: "Chembra Peak", description: "Highest peak with heart-shaped lake trek", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1709730705218-3ccc27971489?w=1080" },
        { name: "Soochipara Falls", description: "Three-tiered waterfall with trekking & rock climbing", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1709730705218-3ccc27971489?w=1080" },
        { name: "Banasura Sagar Dam", description: "Largest earthen dam in India with boating facilities", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1709730705218-3ccc27971489?w=1080" }
      ]
    }
  ],

  "Rajasthan": [
    {
      name: "Jaipur",
      places: [
        { name: "Amer Fort", description: "Majestic hilltop fort with Sheesh Mahal mirror palace", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1663233604615-2f9424ecf33b?w=1080" },
        { name: "Hawa Mahal", description: "Iconic pink palace with 953 honeycomb windows", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1707793044127-bf3b560353e2?w=1080" },
        { name: "City Palace", description: "Royal residence with museums, courtyards & Mughal gardens", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1663233604615-2f9424ecf33b?w=1080" },
        { name: "Jantar Mantar", description: "UNESCO World Heritage astronomical observatory with giant instruments", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1663233604615-2f9424ecf33b?w=1080" },
        { name: "Nahargarh Fort", description: "Tiger fort with stunning city views & sunset points", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1663233604615-2f9424ecf33b?w=1080" },
        { name: "Jal Mahal", description: "Water palace in Man Sagar Lake with Rajput architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1663233604615-2f9424ecf33b?w=1080" }
      ]
    },
    {
      name: "Udaipur",
      places: [
        { name: "City Palace", description: "Stunning palace complex overlooking Lake Pichola", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1622018135960-249abd263aeb?w=1080" },
        { name: "Lake Pichola", description: "Romantic boat rides with palace & island views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1622018135960-249abd263aeb?w=1080" },
        { name: "Jag Mandir", description: "Island palace with marble elegance & lakeside gardens", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1622018135960-249abd263aeb?w=1080" },
        { name: "Saheliyon Ki Bari", description: "Garden of maidens with fountains & lotus pools", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1622018135960-249abd263aeb?w=1080" },
        { name: "Monsoon Palace", description: "Hilltop palace with panoramic views of lakes & hills", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1622018135960-249abd263aeb?w=1080" }
      ]
    },
    {
      name: "Jaisalmer",
      places: [
        { name: "Jaisalmer Fort", description: "Living fort with golden sandstone architecture & shops", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" },
        { name: "Sam Sand Dunes", description: "Desert safari with camel rides & cultural shows under stars", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" },
        { name: "Patwon Ki Haveli", description: "Intricately carved merchant mansions with 60 balconies", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" },
        { name: "Gadisar Lake", description: "Serene lake with temples, cenotaphs & migratory birds", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" },
        { name: "Kuldhara", description: "Abandoned haunted village with mysterious history", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" }
      ]
    },
    {
      name: "Jodhpur",
      places: [
        { name: "Mehrangarh Fort", description: "Massive fort towering 400 feet above the blue city", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1680287097662-28067fabe466?w=1080" },
        { name: "Blue City Streets", description: "Walk through iconic blue-painted old town narrow lanes", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1680287097662-28067fabe466?w=1080" },
        { name: "Umaid Bhawan Palace", description: "Art Deco palace, heritage hotel & museum", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1680287097662-28067fabe466?w=1080" },
        { name: "Jaswant Thada", description: "White marble memorial with latticed windows & lake views", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1680287097662-28067fabe466?w=1080" },
        { name: "Clock Tower & Sardar Market", description: "Bustling market for handicrafts, spices & textiles", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1680287097662-28067fabe466?w=1080" }
      ]
    },
    {
      name: "Pushkar",
      places: [
        { name: "Brahma Temple", description: "Rare Brahma temple, one of very few in the world", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" },
        { name: "Pushkar Lake", description: "Sacred lake with 52 ghats for ritual bathing", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" },
        { name: "Savitri Temple", description: "Hilltop temple with sunrise views over Pushkar", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" },
        { name: "Pushkar Camel Fair Ground", description: "Famous annual camel fair & cultural festival venue", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1645093603488-9d5a1050733a?w=1080" }
      ]
    }
  ],

  "Maharashtra": [
    {
      name: "Mumbai",
      places: [
        { name: "Gateway of India", description: "Iconic archway monument overlooking Arabian Sea harbor", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1598434192043-71111c1b3f41?w=1080" },
        { name: "Marine Drive", description: "Queen's Necklace - stunning sunset views along coastline", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1706216104424-4cc6e96195bc?w=1080" },
        { name: "Elephanta Caves", description: "Island caves with magnificent 6th century Shiva sculptures", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1741207857655-d148b242178a?w=1080" },
        { name: "Siddhivinayak Temple", description: "Famous Ganesh temple with golden dome, must-visit shrine", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1598434192043-71111c1b3f41?w=1080" },
        { name: "Chhatrapati Shivaji Terminus", description: "UNESCO Gothic railway station with Victorian architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1598434192043-71111c1b3f41?w=1080" },
        { name: "Haji Ali Dargah", description: "Floating mosque on island with Indo-Islamic architecture", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1598434192043-71111c1b3f41?w=1080" }
      ]
    },
    {
      name: "Aurangabad",
      places: [
        { name: "Ajanta Caves", description: "Ancient Buddhist rock-cut cave temples with frescoes (UNESCO)", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1626331915556-c4f817fbcc5d?w=1080" },
        { name: "Ellora Caves", description: "Multi-religious rock-cut monasteries with Kailasa temple", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1626331915556-c4f817fbcc5d?w=1080" },
        { name: "Bibi Ka Maqbara", description: "Mini Taj Mahal of the Deccan with Mughal architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1626331915556-c4f817fbcc5d?w=1080" },
        { name: "Daulatabad Fort", description: "Impregnable hilltop fort with ingenious defense systems", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1626331915556-c4f817fbcc5d?w=1080" },
        { name: "Grishneshwar Temple", description: "One of 12 Jyotirlinga shrines with intricate carvings", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1626331915556-c4f817fbcc5d?w=1080" }
      ]
    },
    {
      name: "Pune",
      places: [
        { name: "Shaniwar Wada", description: "Historic Peshwa fortification with grand gateways", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Aga Khan Palace", description: "Mahatma Gandhi memorial with freedom struggle history", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Sinhagad Fort", description: "Hill fort with trekking & historical Maratha battles", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Osho Ashram", description: "International meditation resort with gardens", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Dagdusheth Halwai Ganpati", description: "Famous Ganesh temple with golden idol", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" }
      ]
    },
    {
      name: "Lonavala",
      places: [
        { name: "Bhushi Dam", description: "Popular monsoon waterfall & picnic spot", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Tiger's Leap", description: "Cliff viewpoint with valley views & echo point", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Karla Caves", description: "Ancient Buddhist rock-cut caves with grand chaitya", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Lohagad Fort", description: "Iron fort with monsoon trekking & historic significance", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" }
      ]
    },
    {
      name: "Kolhapur",
      places: [
        { name: "Mahalaxmi Temple", description: "Ancient Shakti Peetha with Ambabai deity", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "New Palace", description: "Rajwada palace with museum & architectural beauty", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Panhala Fort", description: "Largest fort in Deccan with strategic importance", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" },
        { name: "Rankala Lake", description: "Evening hangout spot with boating & street food", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1664872045208-4aea6475f843?w=1080" }
      ]
    }
  ],

  "Goa": [
    {
      name: "North Goa",
      places: [
        { name: "Baga Beach", description: "Popular beach with water sports, shacks & nightlife", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1706806326312-836000df9e1b?w=1080" },
        { name: "Calangute Beach", description: "Queen of beaches with golden sands & beach activities", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1706806326312-836000df9e1b?w=1080" },
        { name: "Fort Aguada", description: "17th-century Portuguese fort with lighthouse & sea views", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1685423142584-8054c84450bd?w=1080" },
        { name: "Chapora Fort", description: "Historic fort with panoramic coastal views (Dil Chahta Hai fame)", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1685423142584-8054c84450bd?w=1080" },
        { name: "Anjuna Flea Market", description: "Wednesday market for handicrafts, jewelry & souvenirs", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1706806326312-836000df9e1b?w=1080" },
        { name: "Vagator Beach", description: "Red cliffs beach with sunset views & trance parties", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1706806326312-836000df9e1b?w=1080" }
      ]
    },
    {
      name: "South Goa",
      places: [
        { name: "Palolem Beach", description: "Crescent-shaped beach with calm waters & kayaking", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1706806326312-836000df9e1b?w=1080" },
        { name: "Basilica of Bom Jesus", description: "UNESCO World Heritage Church with St. Francis Xavier's relics", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1685423142584-8054c84450bd?w=1080" },
        { name: "Dudhsagar Falls", description: "Majestic four-tiered waterfall in Bhagwan Mahavir sanctuary", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" },
        { name: "Colva Beach", description: "Tranquil white sand beach perfect for families", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1706806326312-836000df9e1b?w=1080" },
        { name: "Cabo de Rama Fort", description: "Clifftop fort with stunning Arabian Sea views", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1685423142584-8054c84450bd?w=1080" },
        { name: "Butterfly Beach", description: "Secluded beach accessible by boat, dolphin spotting", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1706806326312-836000df9e1b?w=1080" }
      ]
    }
  ],

  "Tamil Nadu": [
    {
      name: "Chennai",
      places: [
        { name: "Marina Beach", description: "Second longest urban beach in world with sunrise views", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" },
        { name: "Kapaleeshwarar Temple", description: "Ancient Dravidian architecture temple dedicated to Shiva", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" },
        { name: "Fort St. George", description: "First English fortress in India with museum", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" },
        { name: "San Thome Basilica", description: "Gothic revival church built over St. Thomas' tomb", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" },
        { name: "Government Museum", description: "Second oldest museum in India with bronze gallery", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" }
      ]
    },
    {
      name: "Madurai",
      places: [
        { name: "Meenakshi Amman Temple", description: "Colorful temple with 14 gopurams & thousand pillar hall", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" },
        { name: "Thirumalai Nayak Palace", description: "Indo-Saracenic palace with grand halls & light show", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" },
        { name: "Gandhi Memorial Museum", description: "Museum showcasing independence movement & Gandhi's dhoti", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" },
        { name: "Alagar Kovil", description: "Ancient Vishnu temple in Alagar hills with natural springs", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" },
        { name: "Vandiyur Mariamman Teppakulam", description: "Massive temple tank with island temple", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" }
      ]
    },
    {
      name: "Nilgiris (Ooty)",
      places: [
        { name: "Ooty Lake", description: "Scenic lake with boating facilities & garden surrounds", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1632678008080-723a9c4a58e7?w=1080" },
        { name: "Botanical Gardens", description: "Exotic plant collection with fossil tree trunk", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1632678008080-723a9c4a58e7?w=1080" },
        { name: "Doddabetta Peak", description: "Highest peak in Nilgiris with telescope house", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1632678008080-723a9c4a58e7?w=1080" },
        { name: "Nilgiri Mountain Railway", description: "UNESCO heritage toy train through tea estates", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1632678008080-723a9c4a58e7?w=1080" },
        { name: "Rose Garden", description: "Largest rose garden in India with 20,000 varieties", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1632678008080-723a9c4a58e7?w=1080" }
      ]
    },
    {
      name: "Kanchipuram",
      places: [
        { name: "Kailasanathar Temple", description: "Oldest temple with intricate Pallava architecture", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" },
        { name: "Ekambareswarar Temple", description: "Pancha Bhoota Stalam with 3,500-year-old mango tree", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" },
        { name: "Kamakshi Amman Temple", description: "One of 51 Shakti Peethas with golden chariot", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" },
        { name: "Silk Weaving Centers", description: "Famous Kanchipuram silk saree workshops", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1731268381138-9e4d0ec58a15?w=1080" }
      ]
    },
    {
      name: "Kanyakumari",
      places: [
        { name: "Vivekananda Rock Memorial", description: "Memorial on rocky island where Swami meditated", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" },
        { name: "Thiruvalluvar Statue", description: "133-feet tall statue of Tamil poet & philosopher", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" },
        { name: "Kanyakumari Beach", description: "Southernmost tip where three seas meet, sunrise & sunset", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" },
        { name: "Padmanabhapuram Palace", description: "Wooden palace with traditional Kerala architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1568045919115-f2dacbaa1899?w=1080" }
      ]
    }
  ],

  "Uttar Pradesh": [
    {
      name: "Agra",
      places: [
        { name: "Taj Mahal", description: "World's most beautiful monument to love, UNESCO World Heritage", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=1080" },
        { name: "Agra Fort", description: "Red sandstone fortress with Mughal grandeur & Diwan-i-Khas", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1678304644541-08082fa83586?w=1080" },
        { name: "Fatehpur Sikri", description: "Abandoned Mughal capital with Buland Darwaza & Panch Mahal", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=1080" },
        { name: "Mehtab Bagh", description: "Moonlight garden with perfect Taj Mahal sunset views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=1080" },
        { name: "Itmad-ud-Daulah's Tomb", description: "Baby Taj with marble inlay work, Nur Jahan's creation", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=1080" }
      ]
    },
    {
      name: "Varanasi",
      places: [
        { name: "Dashashwamedh Ghat", description: "Most vibrant ghat with evening Ganga Aarti ceremony", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1701619879006-d8a0878b5b5d?w=1080" },
        { name: "Kashi Vishwanath Temple", description: "One of 12 Jyotirlingas, holiest Shiva temple", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1701619879006-d8a0878b5b5d?w=1080" },
        { name: "Sarnath", description: "Buddhist pilgrimage site where Buddha gave first sermon", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1701619879006-d8a0878b5b5d?w=1080" },
        { name: "Assi Ghat", description: "Southern ghat popular for morning yoga & boat rides", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1701619879006-d8a0878b5b5d?w=1080" },
        { name: "Manikarnika Ghat", description: "Main cremation ghat with continuous sacred fires", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1701619879006-d8a0878b5b5d?w=1080" }
      ]
    },
    {
      name: "Lucknow",
      places: [
        { name: "Bara Imambara", description: "Architectural marvel with Bhool Bhulaiya labyrinth maze", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "Rumi Darwaza", description: "Imposing 60-feet gateway of Awadhi architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "Chota Imambara", description: "Palace of Lights with crystal chandeliers & silver throne", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "Hazratganj Market", description: "Historic shopping street with colonial charm & cafes", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "British Residency", description: "Ruins from 1857 uprising with historical significance", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" }
      ]
    },
    {
      name: "Mathura-Vrindavan",
      places: [
        { name: "Krishna Janmabhoomi", description: "Birthplace of Lord Krishna with temple complex", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "Banke Bihari Temple", description: "Most revered Krishna temple with devotional atmosphere", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "ISKCON Vrindavan", description: "Grand Krishna Balaram temple with cultural programs", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "Prem Mandir", description: "Marble temple with stunning light & sound show", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" }
      ]
    },
    {
      name: "Prayagraj (Allahabad)",
      places: [
        { name: "Triveni Sangam", description: "Sacred confluence of Ganga, Yamuna & mythical Saraswati", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "Allahabad Fort", description: "Akbar's fort with Ashoka Pillar & Saraswati Koop", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "Anand Bhawan", description: "Nehru family home turned museum with freedom struggle", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" },
        { name: "Khusro Bagh", description: "Mughal garden with ornate tombs & historical significance", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1583504491444-bc8d6f439779?w=1080" }
      ]
    }
  ],

  "West Bengal": [
    {
      name: "Kolkata",
      places: [
        { name: "Victoria Memorial", description: "Grand marble monument with museum & landscaped gardens", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1697817665440-f988c6d5080f?w=1080" },
        { name: "Howrah Bridge", description: "Iconic cantilever bridge over Hooghly River, engineering marvel", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1677307816181-1446ab18913e?w=1080" },
        { name: "Dakshineswar Kali Temple", description: "Famous Kali temple where Ramakrishna worshipped", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1697817665440-f988c6d5080f?w=1080" },
        { name: "Indian Museum", description: "Oldest & largest museum in India with rare artifacts", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1697817665440-f988c6d5080f?w=1080" },
        { name: "Park Street", description: "Vibrant street with restaurants, cafes & nightlife", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1697817665440-f988c6d5080f?w=1080" },
        { name: "Belur Math", description: "Ramakrishna Mission headquarters with architectural blend", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1697817665440-f988c6d5080f?w=1080" }
      ]
    },
    {
      name: "Darjeeling",
      places: [
        { name: "Tiger Hill", description: "Sunrise viewpoint with Kanchenjunga & Mt. Everest views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" },
        { name: "Darjeeling Himalayan Railway", description: "UNESCO toy train with scenic mountain journey", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" },
        { name: "Tea Gardens", description: "World-famous tea plantations with factory tours", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" },
        { name: "Batasia Loop", description: "Spiral railway track with war memorial & gardens", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" },
        { name: "Peace Pagoda", description: "Japanese Buddhist temple with mountain views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" }
      ]
    },
    {
      name: "Sundarbans",
      places: [
        { name: "Sundarbans National Park", description: "UNESCO mangrove forest & Royal Bengal Tiger reserve", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Sajnekhali Wildlife Sanctuary", description: "Watchtower for tiger & crocodile spotting", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Dobanki Canopy Walk", description: "Elevated walkway through dense mangrove forest", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Sudhanyakhali Watchtower", description: "Best spot for wildlife viewing in Sundarbans", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" }
      ]
    },
    {
      name: "Kalimpong",
      places: [
        { name: "Deolo Hill", description: "Highest point with paragliding & valley views", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" },
        { name: "Durpin Monastery", description: "Buddhist monastery with panoramic Kanchenjunga views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" },
        { name: "Dr. Graham's Homes", description: "Historic Scottish missionary school with museum", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" },
        { name: "Flower Nurseries", description: "Famous orchid & cactus nurseries for plant lovers", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1746175832129-fddb132c075c?w=1080" }
      ]
    }
  ],

  "Himachal Pradesh": [
    {
      name: "Shimla",
      places: [
        { name: "Mall Road", description: "Colonial-era shopping street with Victorian buildings", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" },
        { name: "Jakhu Temple", description: "Hilltop Hanuman temple with giant statue & city views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" },
        { name: "The Ridge", description: "Open space with Christ Church & mountain panoramas", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" },
        { name: "Kufri", description: "Hill station with skiing, hiking & Himalayan views", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" },
        { name: "Viceregal Lodge", description: "British-era building with architecture & history museum", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" }
      ]
    },
    {
      name: "Kullu-Manali",
      places: [
        { name: "Solang Valley", description: "Adventure hub for paragliding, skiing & zorbing", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1655468981043-eccbf08b1d14?w=1080" },
        { name: "Rohtang Pass", description: "High mountain pass with snow activities & scenic drive", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1723641628211-6d08ac6208ce?w=1080" },
        { name: "Hadimba Temple", description: "Ancient wooden temple in cedar forest", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1655468981043-eccbf08b1d14?w=1080" },
        { name: "Old Manali", description: "Hippie village with cafes, music & mountain culture", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1655468981043-eccbf08b1d14?w=1080" },
        { name: "Beas River", description: "White water rafting & riverside camping spot", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1655468981043-eccbf08b1d14?w=1080" }
      ]
    },
    {
      name: "Dharamshala",
      places: [
        { name: "McLeod Ganj", description: "Tibetan culture hub with Dalai Lama's residence", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" },
        { name: "Namgyal Monastery", description: "Dalai Lama's personal monastery with teachings", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" },
        { name: "Triund Trek", description: "Popular overnight trek with Dhauladhar views", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" },
        { name: "Bhagsu Waterfall", description: "Scenic waterfall near Bhagsunath Temple", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" },
        { name: "Dal Lake", description: "Small picturesque lake surrounded by deodar trees", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" }
      ]
    },
    {
      name: "Spiti Valley",
      places: [
        { name: "Key Monastery", description: "1000-year-old Tibetan monastery on hilltop", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" },
        { name: "Chandratal Lake", description: "Moon Lake at 14,000 feet with camping", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" },
        { name: "Kibber Village", description: "One of highest motorable villages with wildlife", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" },
        { name: "Pin Valley National Park", description: "Snow leopard & ibex habitat with cold desert", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1626255047415-fdb067552f9b?w=1080" }
      ]
    },
    {
      name: "Kasauli",
      places: [
        { name: "Monkey Point", description: "Highest point with Hanuman temple & sunset views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" },
        { name: "Christ Church", description: "Gothic church with stained glass windows", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" },
        { name: "Gilbert Trail", description: "Nature walk through dense forest & colonial charm", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" },
        { name: "Sunset Point", description: "Evening viewpoint with valley & mountain panorama", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1609432463625-9bcf935b2dab?w=1080" }
      ]
    }
  ],

  "Uttarakhand": [
    {
      name: "Haridwar",
      places: [
        { name: "Har Ki Pauri", description: "Sacred bathing ghat with evening Ganga Aarti ceremony", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1724432799555-6414c4a669b9?w=1080" },
        { name: "Mansa Devi Temple", description: "Hilltop temple with cable car & wish-fulfilling deity", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1724432799555-6414c4a669b9?w=1080" },
        { name: "Chandi Devi Temple", description: "Ancient temple on Neel Parvat with ropeway", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1724432799555-6414c4a669b9?w=1080" },
        { name: "Rajaji National Park", description: "Elephant corridor with jeep safari & wildlife", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1724432799555-6414c4a669b9?w=1080" }
      ]
    },
    {
      name: "Rishikesh",
      places: [
        { name: "Laxman Jhula", description: "Iconic suspension bridge over Ganges with temples", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" },
        { name: "Ram Jhula", description: "Another suspension bridge connecting ashrams", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" },
        { name: "Parmarth Niketan", description: "Largest ashram with yoga courses & Ganga Aarti", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" },
        { name: "River Rafting", description: "World-class white water rafting on Ganges rapids", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" },
        { name: "Beatles Ashram", description: "Abandoned ashram with graffiti art & meditation caves", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" }
      ]
    },
    {
      name: "Nainital",
      places: [
        { name: "Naini Lake", description: "Picturesque lake surrounded by mountains with boating", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" },
        { name: "Naina Devi Temple", description: "Shakti Peetha temple on northern lake shore", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" },
        { name: "Snow View Point", description: "Cable car ride to panoramic Himalayan views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" },
        { name: "Mall Road", description: "Shopping street with colonial architecture & cafes", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" },
        { name: "Tiffin Top", description: "Dorothy's Seat viewpoint with trekking trails", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" }
      ]
    },
    {
      name: "Mussoorie",
      places: [
        { name: "Kempty Falls", description: "Popular waterfall with swimming & picnic area", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" },
        { name: "Gun Hill", description: "Second highest peak with cable car & valley views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" },
        { name: "Camel's Back Road", description: "Natural rock formation & walking trail", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" },
        { name: "Lal Tibba", description: "Highest point with telescope for mountain viewing", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1659874862799-91ac98446e15?w=1080" }
      ]
    },
    {
      name: "Dehradun",
      places: [
        { name: "Robber's Cave", description: "Natural cave formation with stream & stalactites", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" },
        { name: "Sahastradhara", description: "Sulphur springs with medicinal waters & ropeway", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" },
        { name: "Mindrolling Monastery", description: "Tallest stupa in India with Buddhist architecture", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" },
        { name: "Forest Research Institute", description: "Colonial architecture with museums & gardens", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1572943549994-ee6249cc7ba3?w=1080" }
      ]
    }
  ],

  "Andhra Pradesh": [
    {
      name: "Tirupati",
      places: [
        { name: "Venkateswara Temple", description: "Richest temple in world with 7 hills pilgrimage", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Tirumala Hills", description: "Sacred hills with trekking path & scenic views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Sri Kapileswara Swamy Temple", description: "Ancient Shiva temple at base of Tirumala", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "ISKCON Temple", description: "Golden temple with cultural programs", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    },
    {
      name: "Visakhapatnam",
      places: [
        { name: "RK Beach", description: "Pristine beach with Submarine Museum & aquarium", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1594313059730-8d0a02f44847?w=1080" },
        { name: "Borra Caves", description: "Million-year-old stalactite limestone caves", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" },
        { name: "Araku Valley", description: "Coffee plantations in scenic hill valley with tribal culture", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1683363028862-f4e26cbb1706?w=1080" },
        { name: "Kailasagiri", description: "Hilltop park with ropeway & panoramic city views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1594313059730-8d0a02f44847?w=1080" },
        { name: "Simhachalam Temple", description: "Ancient Narasimha temple on Eastern Ghats", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1594313059730-8d0a02f44847?w=1080" }
      ]
    },
    {
      name: "Vijayawada",
      places: [
        { name: "Kanaka Durga Temple", description: "Hilltop goddess temple overlooking Krishna river", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Prakasam Barrage", description: "Longest dam on Krishna with sunset views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Undavalli Caves", description: "Rock-cut caves with giant reclining Vishnu", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Bhavani Island", description: "River island resort with water sports", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    }
  ],

  "Jammu & Kashmir": [
    {
      name: "Srinagar",
      places: [
        { name: "Dal Lake", description: "Iconic houseboats & shikara rides with floating gardens", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Mughal Gardens", description: "Terraced Shalimar, Nishat & Chashme Shahi gardens", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Shankaracharya Temple", description: "Ancient Shiva temple on hilltop with valley views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Hazratbal Shrine", description: "White marble mosque on Dal Lake shore", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Pari Mahal", description: "Seven-terraced garden palace with panoramic views", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" }
      ]
    },
    {
      name: "Gulmarg",
      places: [
        { name: "Gulmarg Gondola", description: "World's second highest cable car to Apharwat Peak", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1574140843105-b668f16a1da4?w=1080" },
        { name: "Skiing Slopes", description: "Premier skiing destination with powder snow", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1574140843105-b668f16a1da4?w=1080" },
        { name: "Gulmarg Biosphere Reserve", description: "Wildlife sanctuary with musk deer & brown bear", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1574140843105-b668f16a1da4?w=1080" },
        { name: "Alpather Lake", description: "Frozen lake surrounded by snow-capped peaks", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1574140843105-b668f16a1da4?w=1080" }
      ]
    },
    {
      name: "Pahalgam",
      places: [
        { name: "Betaab Valley", description: "Lush green valley named after Bollywood movie", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Aru Valley", description: "Starting point for Amarnath Yatra & trekking", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Lidder River", description: "Trout fishing & white water rafting spot", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Baisaran", description: "Mini Switzerland meadow with horse riding", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" }
      ]
    },
    {
      name: "Leh-Ladakh",
      places: [
        { name: "Pangong Lake", description: "Spectacular blue lake changing colors, 3 Idiots fame", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Nubra Valley", description: "Cold desert with double-humped Bactrian camels", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Magnetic Hill", description: "Gravity-defying hill with optical illusion", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Thiksey Monastery", description: "12-storey monastery resembling Potala Palace", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" },
        { name: "Khardung La Pass", description: "One of highest motorable roads in world", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1665034640942-07c4170c2872?w=1080" }
      ]
    }
  ],

  // Continuing with remaining states...
  "Gujarat": [
    {
      name: "Ahmedabad",
      places: [
        { name: "Sabarmati Ashram", description: "Gandhi's historic ashram on river with museum", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Sidi Saiyyed Mosque", description: "Famous for intricate tree of life stone window", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Adalaj Stepwell", description: "Intricately carved five-storey stepwell with Indo-Islamic architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Kankaria Lake", description: "Circular lake with zoo, toy train & balloon ride", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    },
    {
      name: "Kutch",
      places: [
        { name: "Rann of Kutch", description: "White salt desert with Rann Utsav festival", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Kala Dungar", description: "Black Hill with panoramic Rann views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Dholavira", description: "Harappan civilization archaeological site (UNESCO)", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Handicraft Villages", description: "Traditional embroidery & mirror work artisan villages", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    },
    {
      name: "Somnath-Dwarka",
      places: [
        { name: "Somnath Temple", description: "One of 12 Jyotirlingas rebuilt multiple times", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Dwarkadhish Temple", description: "Krishna's kingdom temple with 5000 years history", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Beyt Dwarka", description: "Island where Krishna lived, accessible by boat", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Nageshwar Jyotirlinga", description: "One of 12 Jyotirlingas with 25-meter Shiva statue", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    }
  ],

  "Punjab": [
    {
      name: "Amritsar",
      places: [
        { name: "Golden Temple", description: "Holiest Sikh gurdwara with gold-plated dome & sarovar", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Jallianwala Bagh", description: "Memorial garden of 1919 massacre", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Wagah Border", description: "Indo-Pak border with beating retreat ceremony", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Partition Museum", description: "Museum documenting India-Pakistan partition", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    },
    {
      name: "Chandigarh",
      places: [
        { name: "Rock Garden", description: "Nek Chand's sculpture garden made from waste", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Sukhna Lake", description: "Man-made lake with boating & walking trail", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Capitol Complex", description: "Le Corbusier's UNESCO World Heritage architecture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Rose Garden", description: "Asia's largest rose garden with 1600 varieties", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    }
  ],

  "Haryana": [
    {
      name: "Gurgaon",
      places: [
        { name: "Kingdom of Dreams", description: "Cultural & entertainment destination with Broadway-style shows", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Cyber Hub", description: "Food & nightlife destination with international cuisines", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Sultanpur National Park", description: "Bird sanctuary with migratory species", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    },
    {
      name: "Kurukshetra",
      places: [
        { name: "Brahma Sarovar", description: "Sacred tank where Mahabharata war was fought", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Jyotisar", description: "Birthplace of Bhagavad Gita with ancient banyan tree", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Kurukshetra Panorama", description: "Museum depicting Mahabharata battle", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    }
  ],

  "Bihar": [
    {
      name: "Bodh Gaya",
      places: [
        { name: "Mahabodhi Temple", description: "UNESCO site where Buddha attained enlightenment", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" },
        { name: "Bodhi Tree", description: "Sacred fig tree descendant of original enlightenment tree", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" },
        { name: "Great Buddha Statue", description: "80-feet tall Buddha statue in meditation posture", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" },
        { name: "Thai Monastery", description: "Beautiful Thai-style Buddhist temple", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" }
      ]
    },
    {
      name: "Patna",
      places: [
        { name: "Golghar", description: "Beehive-shaped granary with spiral staircase", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" },
        { name: "Patna Museum", description: "Ancient artifacts from Mauryan to British era", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" },
        { name: "Mahavir Mandir", description: "One of holiest Hanuman temples in India", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" },
        { name: "Gandhi Ghat", description: "Riverside cremation place of Mahatma Gandhi's ashes", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1736235300171-eb8aa382b594?w=1080" }
      ]
    }
  ],

  "Jharkhand": [
    {
      name: "Ranchi",
      places: [
        { name: "Rock Garden", description: "Artistic rock sculptures & landscaped gardens", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Hundru Falls", description: "320-feet high waterfall on Subarnarekha river", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Jagannath Temple", description: "Replica of Puri temple with rath yatra festival", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Patratu Valley", description: "Dam & valley with scenic reservoir views", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    }
  ],

  "Odisha": [
    {
      name: "Puri",
      places: [
        { name: "Jagannath Temple", description: "Sacred Char Dham pilgrimage with Rath Yatra festival", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Puri Beach", description: "Golden sand beach with sunrise views", type: "Beach", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Chilika Lake", description: "Asia's largest brackish water lagoon with dolphins", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Konark Sun Temple", description: "UNESCO stone chariot temple dedicated to Sun god", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    },
    {
      name: "Bhubaneswar",
      places: [
        { name: "Lingaraj Temple", description: "11th-century temple with Kalinga architecture", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Udayagiri & Khandagiri Caves", description: "Jain rock-cut caves from 2nd century BCE", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Nandankanan Zoo", description: "Botanical garden & zoo with white tigers", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Dhauli Giri", description: "Buddhist site where Ashoka renounced violence", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    }
  ],

  "Chhattisgarh": [
    {
      name: "Bastar",
      places: [
        { name: "Chitrakote Falls", description: "Niagara of India - horseshoe waterfall on Indravati", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" },
        { name: "Tirathgarh Falls", description: "Multi-tiered waterfall amid dense forest", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" },
        { name: "Kanger Valley National Park", description: "Limestone caves & biodiversity hotspot", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" },
        { name: "Tribal Villages", description: "Experience authentic Gond & Maria tribal culture", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" }
      ]
    }
  ],

  "Madhya Pradesh": [
    {
      name: "Bhopal",
      places: [
        { name: "Sanchi Stupa", description: "UNESCO Buddhist monument commissioned by Ashoka", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Bhojpur Temple", description: "Incomplete Shiva temple with massive lingam", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Upper & Lower Lakes", description: "Twin lakes separating old & new city", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Bharat Bhavan", description: "Multi-arts complex & museum", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    },
    {
      name: "Khajuraho",
      places: [
        { name: "Khajuraho Temples", description: "UNESCO erotic sculpture temples from Chandela dynasty", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Kandariya Mahadev Temple", description: "Largest & most ornate temple in complex", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Light & Sound Show", description: "Evening show narrating temple history", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Raneh Falls", description: "Canyon waterfall with crystalline granite rocks", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    }
  ],

  "Assam": [
    {
      name: "Guwahati",
      places: [
        { name: "Kamakhya Temple", description: "Tantric Shakti Peetha on Nilachal Hill", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Umananda Temple", description: "Shiva temple on world's smallest river island", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Brahmaputra River Cruise", description: "Sunset cruise on mighty Brahmaputra river", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Assam State Zoo", description: "Botanical garden with one-horned rhinos", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" }
      ]
    },
    {
      name: "Kaziranga",
      places: [
        { name: "Kaziranga National Park", description: "UNESCO World Heritage with two-thirds of world's one-horned rhinos", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Elephant Safari", description: "Early morning elephant back rhino viewing", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Jeep Safari", description: "Zones tour spotting tigers, elephants & birds", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" },
        { name: "Orchid Park", description: "Biodiversity park with rare orchid species", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1709008502168-afc837c64625?w=1080" }
      ]
    }
  ],

  // Remaining states with basic structure
  "Sikkim": [
    { name: "Gangtok", places: [
      { name: "Tsomgo Lake", description: "Glacial lake at 12,400 feet with yak rides", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Nathula Pass", description: "Indo-China border at 14,140 feet", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Rumtek Monastery", description: "Largest monastery in Sikkim", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
    ]}
  ],

  "Nagaland": [
    { name: "Kohima", places: [
      { name: "War Cemetery", description: "WWII memorial for Allied soldiers", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Kohima Village", description: "Traditional Naga village with angular houses", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Hornbill Festival Ground", description: "Annual tribal culture festival venue", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
    ]}
  ],

  "Manipur": [
    { name: "Imphal", places: [
      { name: "Loktak Lake", description: "Floating phumdi islands & Keibul Lamjao park", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Kangla Fort", description: "Ancient Meitei kings' palace ruins", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Ima Keithel", description: "Asia's largest women-only market", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
    ]}
  ],

  "Tripura": [
    { name: "Agartala", places: [
      { name: "Ujjayanta Palace", description: "Royal museum palace with Mughal gardens", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Neermahal", description: "Water palace in Rudrasagar Lake", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Sepahijala Wildlife Sanctuary", description: "Clouded leopards & spectacled monkeys", type: "Wildlife", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
    ]}
  ],

  "Meghalaya": [
    { name: "Shillong", places: [
      { name: "Elephant Falls", description: "Three-tiered waterfall amid lush greenery", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" },
      { name: "Shillong Peak", description: "Highest point with aerial view of city", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" },
      { name: "Ward's Lake", description: "Horseshoe-shaped lake with gardens", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" }
    ]},
    { name: "Cherrapunji", places: [
      { name: "Living Root Bridges", description: "Natural bridges grown from rubber tree roots", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" },
      { name: "Nohkalikai Falls", description: "India's tallest plunge waterfall at 1115 feet", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" },
      { name: "Mawsmai Cave", description: "Limestone cave with stalactites", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1673462107499-97848ff888b9?w=1080" }
    ]}
  ],

  "Mizoram": [
    { name: "Aizawl", places: [
      { name: "Solomon's Temple", description: "Modern religious structure with crucifixion scenes", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Durtlang Hills", description: "Panoramic viewpoint of Aizawl city", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Mizoram State Museum", description: "Tribal heritage & cultural artifacts", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
    ]}
  ],

  "Arunachal Pradesh": [
    { name: "Tawang", places: [
      { name: "Tawang Monastery", description: "Largest monastery in India, 400 years old", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Sela Pass", description: "High altitude pass at 13,700 feet with frozen lake", type: "Adventure", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
      { name: "Madhuri Lake", description: "Pristine lake amid snow-capped mountains", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
    ]}
  ],

  "Telangana": [
    {
      name: "Hyderabad",
      places: [
        { name: "Charminar", description: "Iconic four-minar monument with bustling markets", type: "Heritage", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Golconda Fort", description: "Fortress city with acoustic marvels & light show", type: "Historical", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Ramoji Film City", description: "World's largest film studio complex (Guinness Record)", type: "Urban", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Hussain Sagar Lake", description: "Heart-shaped lake with Buddha statue on island", type: "Nature", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" },
        { name: "Birla Mandir", description: "White marble temple on hillock with city views", type: "Spiritual", imageUrl: "https://images.unsplash.com/photo-1710633616089-9a1e9ebe3683?w=1080" }
      ]
    }
  ]
};
