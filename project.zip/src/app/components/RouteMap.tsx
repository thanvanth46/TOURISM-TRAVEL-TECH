import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Navigation, Clock, Bike, Bus, CarFront, ZoomIn, ZoomOut, Maximize2, TrendingUp, MapIcon, RouteIcon, AlertTriangle } from 'lucide-react';

// Google Maps API Key
const GOOGLE_MAPS_API_KEY = 'AIzaSyDRS7b1V6_F6bJpRQpJ7qxcatR4SGoSIuE';

// State coordinates for major Indian states
const stateCoordinates: { [key: string]: [number, number] } = {
  "Andhra Pradesh": [15.9129, 79.7400],
  "Arunachal Pradesh": [28.2180, 94.7278],
  "Assam": [26.2006, 92.9376],
  "Bihar": [25.0961, 85.3131],
  "Chhattisgarh": [21.2787, 81.8661],
  "Goa": [15.2993, 74.1240],
  "Gujarat": [22.2587, 71.1924],
  "Haryana": [29.0588, 76.0856],
  "Himachal Pradesh": [31.1048, 77.1734],
  "Jharkhand": [23.6102, 85.2799],
  "Karnataka": [15.3173, 75.7139],
  "Kerala": [10.8505, 76.2711],
  "Madhya Pradesh": [22.9734, 78.6569],
  "Maharashtra": [19.7515, 75.7139],
  "Manipur": [24.6637, 93.9063],
  "Meghalaya": [25.4670, 91.3662],
  "Mizoram": [23.1645, 92.9376],
  "Nagaland": [26.1584, 94.5624],
  "Odisha": [20.9517, 85.0985],
  "Punjab": [31.1471, 75.3412],
  "Rajasthan": [27.0238, 74.2179],
  "Sikkim": [27.5330, 88.5122],
  "Tamil Nadu": [11.1271, 78.6569],
  "Telangana": [18.1124, 79.0193],
  "Tripura": [23.9408, 91.9882],
  "Uttar Pradesh": [26.8467, 80.9462],
  "Uttarakhand": [30.0668, 79.0193],
  "West Bengal": [22.9868, 87.8550],
  "Delhi": [28.7041, 77.1025]
};

interface RouteMapProps {
  fromState: string;
  toState: string;
  transportMode: 'car' | 'bike' | 'bus';
}

interface RouteInfo {
  distance: string;
  duration: string;
  distanceValue: number;
  durationValue: number;
}

// Dark mode map styles
const darkMapStyles = [
  { elementType: "geometry", stylers: [{ color: "#1a1f2e" }] },
  { elementType: "labels.text.stroke", stylers: [{ color: "#1a1f2e" }] },
  { elementType: "labels.text.fill", stylers: [{ color: "#8b92ab" }] },
  {
    featureType: "administrative.locality",
    elementType: "labels.text.fill",
    stylers: [{ color: "#60a5fa" }],
  },
  {
    featureType: "poi",
    elementType: "labels.text.fill",
    stylers: [{ color: "#6366f1" }],
  },
  {
    featureType: "poi.park",
    elementType: "geometry",
    stylers: [{ color: "#1e3a2e" }],
  },
  {
    featureType: "poi.park",
    elementType: "labels.text.fill",
    stylers: [{ color: "#34d399" }],
  },
  {
    featureType: "road",
    elementType: "geometry",
    stylers: [{ color: "#2d3748" }],
  },
  {
    featureType: "road",
    elementType: "geometry.stroke",
    stylers: [{ color: "#1a202c" }],
  },
  {
    featureType: "road",
    elementType: "labels.text.fill",
    stylers: [{ color: "#9ca3af" }],
  },
  {
    featureType: "road.highway",
    elementType: "geometry",
    stylers: [{ color: "#4338ca" }],
  },
  {
    featureType: "road.highway",
    elementType: "geometry.stroke",
    stylers: [{ color: "#312e81" }],
  },
  {
    featureType: "road.highway",
    elementType: "labels.text.fill",
    stylers: [{ color: "#c7d2fe" }],
  },
  {
    featureType: "transit",
    elementType: "geometry",
    stylers: [{ color: "#374151" }],
  },
  {
    featureType: "transit.station",
    elementType: "labels.text.fill",
    stylers: [{ color: "#60a5fa" }],
  },
  {
    featureType: "water",
    elementType: "geometry",
    stylers: [{ color: "#0f172a" }],
  },
  {
    featureType: "water",
    elementType: "labels.text.fill",
    stylers: [{ color: "#3b82f6" }],
  },
  {
    featureType: "water",
    elementType: "labels.text.stroke",
    stylers: [{ color: "#0f172a" }],
  },
];

export function RouteMap({ fromState, toState, transportMode }: RouteMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);
  const trafficLayerRef = useRef<google.maps.TrafficLayer | null>(null);
  
  const [isLoaded, setIsLoaded] = useState(false);
  const [showTracking, setShowTracking] = useState(false);
  const [showTraffic, setShowTraffic] = useState(false);
  const [mapType, setMapType] = useState<'roadmap' | 'satellite' | 'hybrid' | 'terrain'>('roadmap');
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  const [alternativeRoutes, setAlternativeRoutes] = useState<google.maps.DirectionsRoute[]>([]);
  const [selectedRouteIndex, setSelectedRouteIndex] = useState(0);
  const [vehiclePosition, setVehiclePosition] = useState(0);
  const [isCalculating, setIsCalculating] = useState(false);
  const [hasError, setHasError] = useState(false);
  const vehicleMarkerRef = useRef<google.maps.Marker | null>(null);

  const startCoords = stateCoordinates[fromState];
  const endCoords = stateCoordinates[toState];

  // Colors for different transport modes
  const colors = {
    car: '#a855f7',
    bike: '#ef4444',
    bus: '#f97316'
  };

  const Icons = {
    car: CarFront,
    bike: Bike,
    bus: Bus
  };

  const ModeIcon = Icons[transportMode];

  // Calculate distance between two coordinates (Haversine formula)
  const calculateDistance = (start: [number, number], end: [number, number]) => {
    const R = 6371; // Earth's radius in km
    const dLat = (end[0] - start[0]) * Math.PI / 180;
    const dLon = (end[1] - start[1]) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(start[0] * Math.PI / 180) * Math.cos(end[0] * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
  };

  // Calculate estimated time
  const calculateTime = (distance: number, mode: string) => {
    const speeds = { car: 60, bike: 50, bus: 50 }; // km/h
    const hours = distance / speeds[mode as keyof typeof speeds];
    return hours < 1 ? `${Math.round(hours * 60)} mins` : `${Math.round(hours)} hrs`;
  };

  // Load Google Maps script dynamically
  useEffect(() => {
    // Check if script already loaded
    if (window.google && window.google.maps) {
      setIsLoaded(true);
      return;
    }

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places,geometry&callback=initMap`;
    script.async = true;
    script.defer = true;

    // Define callback
    (window as any).initMap = () => {
      setIsLoaded(true);
    };

    script.onerror = () => {
      console.error('Failed to load Google Maps');
      setHasError(true);
    };

    document.head.appendChild(script);

    return () => {
      delete (window as any).initMap;
    };
  }, []);

  // Create map instance and calculate route
  useEffect(() => {
    if (!isLoaded || !mapRef.current || !startCoords || !endCoords || hasError) return;

    try {
      // Create map
      const map = new google.maps.Map(mapRef.current, {
        center: { 
          lat: (startCoords[0] + endCoords[0]) / 2, 
          lng: (startCoords[1] + endCoords[1]) / 2 
        },
        zoom: 6,
        mapTypeId: mapType,
        styles: darkMapStyles,
        disableDefaultUI: true,
        zoomControl: false,
        mapTypeControl: false,
        scaleControl: true,
        streetViewControl: false,
        rotateControl: false,
        fullscreenControl: false,
      });

      mapInstanceRef.current = map;

      // Add custom markers for start and end
      new google.maps.Marker({
        position: { lat: startCoords[0], lng: startCoords[1] },
        map: map,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 12,
          fillColor: '#10b981',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 3,
        },
        title: fromState,
        label: {
          text: 'A',
          color: '#ffffff',
          fontWeight: 'bold',
        },
      });

      new google.maps.Marker({
        position: { lat: endCoords[0], lng: endCoords[1] },
        map: map,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 12,
          fillColor: '#ef4444',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 3,
        },
        title: toState,
        label: {
          text: 'B',
          color: '#ffffff',
          fontWeight: 'bold',
        },
      });

      // Initialize directions renderer with custom styles
      const directionsRenderer = new google.maps.DirectionsRenderer({
        map: map,
        suppressMarkers: true, // Use custom markers
        polylineOptions: {
          strokeColor: colors[transportMode],
          strokeWeight: 5,
          strokeOpacity: 0.8,
        },
      });

      directionsRendererRef.current = directionsRenderer;

      // Try to calculate route with Google Directions API
      setIsCalculating(true);
      const directionsService = new google.maps.DirectionsService();
      
      const travelModeMap: { [key: string]: google.maps.TravelMode } = {
        car: google.maps.TravelMode.DRIVING,
        bike: google.maps.TravelMode.DRIVING,
        bus: google.maps.TravelMode.TRANSIT
      };

      const request: google.maps.DirectionsRequest = {
        origin: { lat: startCoords[0], lng: startCoords[1] },
        destination: { lat: endCoords[0], lng: endCoords[1] },
        travelMode: travelModeMap[transportMode] || google.maps.TravelMode.DRIVING,
        provideRouteAlternatives: true,
      };

      directionsService.route(request, (result, status) => {
        setIsCalculating(false);
        
        if (status === 'OK' && result) {
          directionsRenderer.setDirections(result);
          
          if (result.routes) {
            setAlternativeRoutes(result.routes);
            
            const route = result.routes[0];
            if (route.legs && route.legs[0]) {
              const leg = route.legs[0];
              setRouteInfo({
                distance: leg.distance?.text || 'N/A',
                duration: leg.duration?.text || 'N/A',
                distanceValue: leg.distance?.value || 0,
                durationValue: leg.duration?.value || 0,
              });
            }
          }
        } else {
          // Fallback: Draw straight line
          console.warn('Directions API failed, using fallback:', status);
          
          const path = [
            { lat: startCoords[0], lng: startCoords[1] },
            { lat: endCoords[0], lng: endCoords[1] }
          ];

          new google.maps.Polyline({
            path: path,
            geodesic: true,
            strokeColor: colors[transportMode],
            strokeOpacity: 0.8,
            strokeWeight: 5,
            map: map,
          });

          // Calculate fallback distance and time
          const distance = calculateDistance(startCoords, endCoords);
          const duration = calculateTime(distance, transportMode);
          
          setRouteInfo({
            distance: `${distance} km`,
            duration: duration,
            distanceValue: distance * 1000,
            durationValue: parseInt(duration) * 60,
          });
        }
      });
    } catch (error) {
      console.error('Error creating map:', error);
      setHasError(true);
    }

    return () => {
      if (trafficLayerRef.current) {
        trafficLayerRef.current.setMap(null);
      }
    };
  }, [isLoaded, fromState, toState, transportMode, mapType, hasError]);

  // Handle traffic layer toggle
  useEffect(() => {
    if (!mapInstanceRef.current || !isLoaded) return;

    try {
      if (showTraffic) {
        if (!trafficLayerRef.current) {
          trafficLayerRef.current = new google.maps.TrafficLayer();
        }
        trafficLayerRef.current.setMap(mapInstanceRef.current);
      } else {
        if (trafficLayerRef.current) {
          trafficLayerRef.current.setMap(null);
        }
      }
    } catch (error) {
      console.error('Error toggling traffic:', error);
    }
  }, [showTraffic, isLoaded]);

  // Handle vehicle tracking animation
  useEffect(() => {
    if (!showTracking || !mapInstanceRef.current || !alternativeRoutes.length) return;

    const route = alternativeRoutes[selectedRouteIndex];
    const path = route.overview_path;
    
    if (!path || path.length === 0) return;

    let currentIndex = 0;

    const vehicleMarker = new google.maps.Marker({
      position: path[0],
      map: mapInstanceRef.current,
      icon: {
        path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
        scale: 6,
        fillColor: colors[transportMode],
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 2,
      },
      title: `${transportMode} in transit`,
    });

    vehicleMarkerRef.current = vehicleMarker;

    const interval = setInterval(() => {
      currentIndex = (currentIndex + 1) % path.length;
      const position = path[currentIndex];
      
      vehicleMarker.setPosition(position);
      setVehiclePosition(Math.round((currentIndex / path.length) * 100));

      if (mapInstanceRef.current) {
        mapInstanceRef.current.panTo(position);
      }
    }, 100);

    return () => {
      clearInterval(interval);
      if (vehicleMarkerRef.current) {
        vehicleMarkerRef.current.setMap(null);
      }
    };
  }, [showTracking, selectedRouteIndex, alternativeRoutes, transportMode]);

  // Handle route selection
  const handleRouteSelect = (index: number) => {
    if (directionsRendererRef.current && alternativeRoutes[index]) {
      setSelectedRouteIndex(index);
      directionsRendererRef.current.setRouteIndex(index);
      
      const route = alternativeRoutes[index];
      if (route.legs && route.legs[0]) {
        const leg = route.legs[0];
        setRouteInfo({
          distance: leg.distance?.text || 'N/A',
          duration: leg.duration?.text || 'N/A',
          distanceValue: leg.distance?.value || 0,
          durationValue: leg.duration?.value || 0,
        });
      }
    }
  };

  // Handle zoom controls
  const handleZoomIn = () => {
    if (mapInstanceRef.current) {
      const currentZoom = mapInstanceRef.current.getZoom() || 10;
      mapInstanceRef.current.setZoom(currentZoom + 1);
    }
  };

  const handleZoomOut = () => {
    if (mapInstanceRef.current) {
      const currentZoom = mapInstanceRef.current.getZoom() || 10;
      mapInstanceRef.current.setZoom(currentZoom - 1);
    }
  };

  const handleFitBounds = () => {
    if (mapInstanceRef.current && startCoords && endCoords) {
      const bounds = new google.maps.LatLngBounds();
      bounds.extend({ lat: startCoords[0], lng: startCoords[1] });
      bounds.extend({ lat: endCoords[0], lng: endCoords[1] });
      mapInstanceRef.current.fitBounds(bounds);
    }
  };

  if (!startCoords || !endCoords) {
    return (
      <div className="w-full h-96 bg-slate-900/50 rounded-xl border border-slate-700/50 flex items-center justify-center">
        <p className="text-slate-400">Select valid destinations to view map</p>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="w-full h-96 bg-slate-900/50 rounded-xl border border-red-700/50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-red-400 font-semibold mb-2">Google Maps API Error</p>
          <p className="text-slate-400 text-sm">Unable to load map. Please check API configuration.</p>
        </div>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="w-full h-96 bg-slate-900/50 rounded-xl border border-slate-700/50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500 mx-auto mb-4"></div>
          <p className="text-slate-400">Loading Google Maps...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Map Controls Header */}
      <div className="flex items-center justify-between bg-gradient-to-r from-slate-900/90 to-slate-800/90 backdrop-blur-sm border border-slate-700/50 rounded-xl p-4 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 flex items-center justify-center shadow-lg shadow-purple-500/50 animate-pulse">
            <ModeIcon className="w-7 h-7 text-white" />
          </div>
          <div>
            <h4 className="font-bold text-white text-lg capitalize flex items-center gap-2">
              {transportMode} Route
              <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded-full border border-green-500/30">
                Google Maps Powered
              </span>
            </h4>
            <p className="text-sm text-slate-400">{fromState} → {toState}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          {routeInfo && (
            <>
              <div className="text-center">
                <p className="text-xs text-slate-400">Distance</p>
                <p className="font-bold text-white text-lg">{routeInfo.distance}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-slate-400 flex items-center gap-1 justify-center">
                  <Clock className="w-3 h-3" />
                  Est. Time
                </p>
                <p className="font-bold text-white text-lg">{routeInfo.duration}</p>
              </div>
            </>
          )}
          <button
            onClick={() => setShowTracking(!showTracking)}
            disabled={!alternativeRoutes.length}
            className={`px-5 py-2.5 rounded-lg font-semibold text-sm transition-all shadow-lg flex items-center gap-2 ${ 
              showTracking
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-green-500/50'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed'
            }`}
          >
            {showTracking ? (
              <>
                <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                Live Tracking
              </>
            ) : (
              <>
                <Navigation className="w-4 h-4" />
                Start Tracking
              </>
            )}
          </button>
        </div>
      </div>
      
      {/* Map Container */}
      <div className="relative w-full h-[600px] rounded-xl overflow-hidden border-2 border-slate-700/50 shadow-2xl">
        <div ref={mapRef} className="w-full h-full" />
        
        {/* Loading Overlay */}
        {isCalculating && (
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center z-[1000]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-cyan-500 mx-auto mb-4"></div>
              <p className="text-white font-semibold text-lg">Calculating Best Route...</p>
              <p className="text-slate-400 text-sm mt-2">Using Google Maps Directions API</p>
            </div>
          </div>
        )}
        
        {/* Custom Map Controls */}
        <div className="absolute top-4 left-4 z-[1000] flex flex-col gap-2">
          <button
            onClick={handleZoomIn}
            className="w-11 h-11 bg-slate-900/95 backdrop-blur-sm border border-slate-700 rounded-lg flex items-center justify-center text-white hover:bg-slate-800 hover:border-cyan-500 transition-all shadow-lg"
            title="Zoom In"
          >
            <ZoomIn className="w-5 h-5" />
          </button>
          <button
            onClick={handleZoomOut}
            className="w-11 h-11 bg-slate-900/95 backdrop-blur-sm border border-slate-700 rounded-lg flex items-center justify-center text-white hover:bg-slate-800 hover:border-cyan-500 transition-all shadow-lg"
            title="Zoom Out"
          >
            <ZoomOut className="w-5 h-5" />
          </button>
          <button
            onClick={handleFitBounds}
            className="w-11 h-11 bg-slate-900/95 backdrop-blur-sm border border-slate-700 rounded-lg flex items-center justify-center text-white hover:bg-slate-800 hover:border-cyan-500 transition-all shadow-lg"
            title="Fit to Route"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
        </div>

        {/* Map Type & Traffic Controls */}
        <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2">
          <div className="bg-slate-900/95 backdrop-blur-sm border border-slate-700 rounded-lg p-2">
            <div className="flex gap-1">
              {(['roadmap', 'satellite', 'hybrid', 'terrain'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => {
                    setMapType(type);
                    if (mapInstanceRef.current) {
                      mapInstanceRef.current.setMapTypeId(type);
                    }
                  }}
                  className={`px-3 py-1.5 rounded text-xs font-semibold capitalize transition-all ${
                    mapType === type
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {type === 'roadmap' ? 'Road' : type}
                </button>
              ))}
            </div>
          </div>
          
          <button
            onClick={() => setShowTraffic(!showTraffic)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all backdrop-blur-sm ${
              showTraffic
                ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white border border-orange-400'
                : 'bg-slate-900/95 text-slate-400 hover:text-white border border-slate-700'
            }`}
          >
            🚦 Traffic {showTraffic ? 'ON' : 'OFF'}
          </button>
        </div>

        {/* Alternative Routes */}
        {alternativeRoutes.length > 1 && (
          <div className="absolute bottom-4 left-4 z-[1000] bg-slate-900/95 backdrop-blur-sm border border-slate-700 rounded-lg p-3 max-w-xs">
            <h5 className="text-white font-bold text-sm mb-2 flex items-center gap-2">
              <RouteIcon className="w-4 h-4 text-cyan-400" />
              Alternative Routes ({alternativeRoutes.length})
            </h5>
            <div className="space-y-2">
              {alternativeRoutes.map((route, index) => (
                <button
                  key={index}
                  onClick={() => handleRouteSelect(index)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-all ${
                    selectedRouteIndex === index
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Route {index + 1}</span>
                    <span>{route.legs?.[0]?.duration?.text}</span>
                  </div>
                  <div className="text-[10px] mt-1 opacity-80">
                    {route.legs?.[0]?.distance?.text} • {route.summary}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
        
        {/* Tracking Info Overlay */}
        <AnimatePresence>
          {showTracking && routeInfo && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-20 right-4 bg-slate-900/95 backdrop-blur-xl border-2 border-green-500/50 rounded-xl p-5 shadow-2xl z-[1000] min-w-[320px]"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="relative">
                  <Navigation className="w-7 h-7 text-green-400 animate-pulse" />
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-ping"></div>
                </div>
                <div>
                  <p className="font-bold text-white text-base">Live Tracking Active</p>
                  <p className="text-xs text-green-400">Real-time GPS updates • Google Maps</p>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Journey Progress</span>
                  <span className="text-white font-bold">{vehiclePosition}%</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-green-500 via-emerald-500 to-cyan-500"
                    style={{ width: `${vehiclePosition}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">
                    <span className="text-green-400 font-semibold">
                      {Math.round((routeInfo.distanceValue / 1000) * vehiclePosition / 100)} km
                    </span> completed
                  </span>
                  <span className="text-slate-400">
                    <span className="text-orange-400 font-semibold">
                      {Math.round((routeInfo.distanceValue / 1000) * (100 - vehiclePosition) / 100)} km
                    </span> remaining
                  </span>
                </div>
                <div className="mt-3 pt-3 border-t border-slate-700">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">ETA:</span>
                    <span className="text-cyan-400 font-semibold">
                      {Math.round((routeInfo.durationValue / 60) * (100 - vehiclePosition) / 100)} mins
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      {/* Route Details */}
      {routeInfo && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/30 rounded-xl p-5 hover:scale-105 transition-transform"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <MapPin className="w-5 h-5 text-blue-400" />
              </div>
              <h5 className="font-bold text-white text-lg">Route Type</h5>
            </div>
            <p className="text-sm text-slate-300 font-semibold">
              {alternativeRoutes[selectedRouteIndex]?.summary || 'Fastest Route'}
            </p>
            <p className="text-xs text-slate-400 mt-1">Via Google Maps Directions</p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-xl p-5 hover:scale-105 transition-transform"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <Clock className="w-5 h-5 text-purple-400" />
              </div>
              <h5 className="font-bold text-white text-lg">Travel Time</h5>
            </div>
            <p className="text-sm text-slate-300 font-semibold">{routeInfo.duration}</p>
            <p className="text-xs text-slate-400 mt-1">Real-time traffic included</p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-orange-500/10 to-yellow-500/10 border border-orange-500/30 rounded-xl p-5 hover:scale-105 transition-transform"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center">
                <Navigation className="w-5 h-5 text-orange-400" />
              </div>
              <h5 className="font-bold text-white text-lg">Distance</h5>
            </div>
            <p className="text-sm text-slate-300 font-semibold">{routeInfo.distance}</p>
            <p className="text-xs text-slate-400 mt-1">Accurate GPS measurements</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-xl p-5 hover:scale-105 transition-transform"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-400" />
              </div>
              <h5 className="font-bold text-white text-lg">Traffic Status</h5>
            </div>
            <p className="text-sm text-slate-300 font-semibold">
              {showTraffic ? 'Live Traffic' : 'Traffic Off'}
            </p>
            <p className="text-xs text-slate-400 mt-1">
              {showTraffic ? 'Real-time conditions' : 'Enable for updates'}
            </p>
          </motion.div>
        </div>
      )}

      {/* Google Maps Attribution */}
      <div className="flex items-center justify-center gap-2 text-xs text-slate-500">
        <MapIcon className="w-3 h-3" />
        <span>Powered by Google Maps API • Real-time routing and traffic data</span>
      </div>
    </div>
  );
}
