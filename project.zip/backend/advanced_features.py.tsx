"""
Advanced Supabase Features Demo
Real-time subscriptions, Storage, and Edge Functions
"""

from supabase import create_client, Client
import os
from typing import Callable
import asyncio

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# ============================================
# Real-time Subscriptions
# ============================================

class RealtimeBookings:
    """Handle real-time booking updates"""
    
    def __init__(self):
        self.channel = None
    
    def subscribe_to_bookings(self, callback: Callable):
        """
        Subscribe to booking changes in real-time
        
        Usage:
            def on_booking_change(payload):
                print(f"Booking updated: {payload}")
            
            rt = RealtimeBookings()
            rt.subscribe_to_bookings(on_booking_change)
        """
        self.channel = supabase.channel('public:bookings')
        
        def handle_change(payload):
            event = payload.get('eventType')
            data = payload.get('new', {})
            old_data = payload.get('old', {})
            
            if event == 'INSERT':
                print(f"🆕 New booking created: {data.get('id')}")
            elif event == 'UPDATE':
                print(f"📝 Booking updated: {data.get('id')}")
            elif event == 'DELETE':
                print(f"🗑️ Booking deleted: {old_data.get('id')}")
            
            callback(payload)
        
        self.channel.on('postgres_changes', 
                       event='*', 
                       schema='public', 
                       table='bookings', 
                       callback=handle_change)
        
        self.channel.subscribe()
        print("✅ Subscribed to booking updates")
    
    def unsubscribe(self):
        """Unsubscribe from updates"""
        if self.channel:
            supabase.remove_channel(self.channel)
            print("❌ Unsubscribed from booking updates")

# ============================================
# Storage Operations
# ============================================

class StorageManager:
    """Handle Supabase Storage operations"""
    
    def __init__(self, bucket_name: str = "travel-photos"):
        self.bucket = bucket_name
    
    def upload_file(self, file_path: str, destination_path: str):
        """
        Upload file to Supabase Storage
        
        Args:
            file_path: Local file path
            destination_path: Path in bucket (e.g., "user123/photo.jpg")
        """
        try:
            with open(file_path, 'rb') as f:
                file_content = f.read()
            
            response = supabase.storage.from_(self.bucket).upload(
                destination_path,
                file_content
            )
            
            public_url = supabase.storage.from_(self.bucket).get_public_url(destination_path)
            
            print(f"✅ File uploaded: {public_url}")
            return public_url
        
        except Exception as e:
            print(f"❌ Upload failed: {str(e)}")
            return None
    
    def download_file(self, source_path: str, destination_path: str):
        """Download file from Supabase Storage"""
        try:
            response = supabase.storage.from_(self.bucket).download(source_path)
            
            with open(destination_path, 'wb') as f:
                f.write(response)
            
            print(f"✅ File downloaded to: {destination_path}")
            return True
        
        except Exception as e:
            print(f"❌ Download failed: {str(e)}")
            return False
    
    def list_files(self, folder_path: str = ""):
        """List all files in folder"""
        try:
            files = supabase.storage.from_(self.bucket).list(folder_path)
            print(f"📂 Files in {folder_path or 'root'}:")
            for file in files:
                print(f"  - {file['name']} ({file.get('metadata', {}).get('size', 0)} bytes)")
            return files
        
        except Exception as e:
            print(f"❌ List failed: {str(e)}")
            return []
    
    def delete_file(self, file_path: str):
        """Delete file from storage"""
        try:
            supabase.storage.from_(self.bucket).remove([file_path])
            print(f"✅ File deleted: {file_path}")
            return True
        
        except Exception as e:
            print(f"❌ Delete failed: {str(e)}")
            return False
    
    def create_signed_url(self, file_path: str, expires_in: int = 3600):
        """
        Create temporary signed URL for private files
        
        Args:
            file_path: Path to file in bucket
            expires_in: Expiration time in seconds (default 1 hour)
        """
        try:
            response = supabase.storage.from_(self.bucket).create_signed_url(
                file_path,
                expires_in
            )
            
            signed_url = response.get('signedURL')
            print(f"✅ Signed URL created (expires in {expires_in}s)")
            return signed_url
        
        except Exception as e:
            print(f"❌ Signed URL failed: {str(e)}")
            return None

# ============================================
# Advanced Queries
# ============================================

class AdvancedQueries:
    """Advanced Supabase query patterns"""
    
    @staticmethod
    def full_text_search(query: str, table: str = "reviews"):
        """
        Full-text search in reviews
        
        Usage:
            results = AdvancedQueries.full_text_search("amazing beach")
        """
        try:
            response = supabase.table(table).select("*").text_search(
                'review_text',
                query,
                config='english'
            ).execute()
            
            print(f"🔍 Found {len(response.data)} results for '{query}'")
            return response.data
        
        except Exception as e:
            print(f"❌ Search failed: {str(e)}")
            return []
    
    @staticmethod
    def complex_join_query(user_id: str):
        """
        Complex query with joins and aggregations
        Get user with their bookings, reviews, and stats
        """
        try:
            # Get user profile
            profile = supabase.table("profiles").select("*").eq("id", user_id).single().execute()
            
            # Get bookings with count
            bookings = supabase.table("bookings").select("*").eq("user_id", user_id).execute()
            
            # Get reviews
            reviews = supabase.table("reviews").select("*").eq("user_id", user_id).execute()
            
            # Get photos
            photos = supabase.table("travel_photos").select("*").eq("user_id", user_id).execute()
            
            result = {
                "profile": profile.data,
                "bookings": bookings.data,
                "bookings_count": len(bookings.data),
                "reviews": reviews.data,
                "reviews_count": len(reviews.data),
                "photos": photos.data,
                "photos_count": len(photos.data)
            }
            
            print(f"✅ Retrieved complete user data")
            return result
        
        except Exception as e:
            print(f"❌ Query failed: {str(e)}")
            return None
    
    @staticmethod
    def aggregate_query():
        """
        Aggregate bookings by state and transport mode
        """
        try:
            bookings = supabase.table("bookings").select("to_state, transport_mode").execute()
            
            # Manual aggregation (Supabase doesn't support GROUP BY directly)
            aggregated = {}
            for booking in bookings.data:
                state = booking['to_state']
                mode = booking['transport_mode']
                key = f"{state}_{mode}"
                
                if key not in aggregated:
                    aggregated[key] = {
                        'state': state,
                        'mode': mode,
                        'count': 0
                    }
                aggregated[key]['count'] += 1
            
            result = list(aggregated.values())
            print(f"📊 Aggregated {len(result)} state-mode combinations")
            return result
        
        except Exception as e:
            print(f"❌ Aggregation failed: {str(e)}")
            return []
    
    @staticmethod
    def pagination_example(page: int = 1, per_page: int = 10):
        """
        Paginated query with sorting
        """
        try:
            start = (page - 1) * per_page
            end = start + per_page - 1
            
            response = supabase.table("bookings").select("*", count="exact").order(
                "created_at",
                desc=True
            ).range(start, end).execute()
            
            total = response.count
            total_pages = (total + per_page - 1) // per_page
            
            print(f"📄 Page {page}/{total_pages} ({len(response.data)} items)")
            
            return {
                "data": response.data,
                "page": page,
                "per_page": per_page,
                "total": total,
                "total_pages": total_pages
            }
        
        except Exception as e:
            print(f"❌ Pagination failed: {str(e)}")
            return None

# ============================================
# Batch Operations
# ============================================

class BatchOperations:
    """Efficient batch operations"""
    
    @staticmethod
    def bulk_insert(table: str, records: list):
        """
        Insert multiple records at once
        
        Usage:
            records = [
                {"user_id": "123", "state_name": "Goa", ...},
                {"user_id": "123", "state_name": "Kerala", ...}
            ]
            BatchOperations.bulk_insert("favorites", records)
        """
        try:
            response = supabase.table(table).insert(records).execute()
            print(f"✅ Inserted {len(response.data)} records")
            return response.data
        
        except Exception as e:
            print(f"❌ Bulk insert failed: {str(e)}")
            return []
    
    @staticmethod
    def bulk_update(table: str, records: list):
        """Update multiple records"""
        try:
            results = []
            for record in records:
                record_id = record.pop('id')
                response = supabase.table(table).update(record).eq('id', record_id).execute()
                results.extend(response.data)
            
            print(f"✅ Updated {len(results)} records")
            return results
        
        except Exception as e:
            print(f"❌ Bulk update failed: {str(e)}")
            return []
    
    @staticmethod
    def bulk_delete(table: str, ids: list):
        """Delete multiple records by ID"""
        try:
            response = supabase.table(table).delete().in_('id', ids).execute()
            print(f"✅ Deleted {len(response.data)} records")
            return True
        
        except Exception as e:
            print(f"❌ Bulk delete failed: {str(e)}")
            return False

# ============================================
# Demo Usage
# ============================================

if __name__ == "__main__":
    print("\n" + "="*60)
    print("🚀 SUPABASE ADVANCED FEATURES DEMO")
    print("="*60 + "\n")
    
    # 1. Real-time Subscriptions Demo
    print("1️⃣ Real-time Subscriptions")
    print("-" * 60)
    rt = RealtimeBookings()
    
    def on_change(payload):
        print(f"📡 Real-time update received: {payload.get('eventType')}")
    
    # Uncomment to test real-time
    # rt.subscribe_to_bookings(on_change)
    # time.sleep(30)  # Keep listening for 30 seconds
    # rt.unsubscribe()
    
    # 2. Storage Operations Demo
    print("\n2️⃣ Storage Operations")
    print("-" * 60)
    storage = StorageManager()
    # storage.list_files()
    
    # 3. Advanced Queries Demo
    print("\n3️⃣ Advanced Queries")
    print("-" * 60)
    
    # Full-text search
    # results = AdvancedQueries.full_text_search("beach")
    
    # Pagination
    # page_data = AdvancedQueries.pagination_example(page=1, per_page=5)
    
    # 4. Batch Operations Demo
    print("\n4️⃣ Batch Operations")
    print("-" * 60)
    
    # Example batch insert
    # favorites = [
    #     {"user_id": "user-123", "state_name": "Goa", "notes": "Love the beaches"},
    #     {"user_id": "user-123", "state_name": "Kerala", "notes": "Amazing backwaters"}
    # ]
    # BatchOperations.bulk_insert("favorites", favorites)
    
    print("\n" + "="*60)
    print("✅ Demo completed!")
    print("="*60 + "\n")
