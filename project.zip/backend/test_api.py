"""
Test Suite for IAGI Warriors Travel API
Demonstrates Supabase integration with Python
"""

import requests
import json
from datetime import date, timedelta

# Configuration
BASE_URL = "http://localhost:8000"
TEST_EMAIL = "test@iagiwarriors.com"
TEST_PASSWORD = "SecurePassword123!"
TOKEN = None

def print_response(title, response):
    """Pretty print API response"""
    print(f"\n{'='*60}")
    print(f"📍 {title}")
    print(f"{'='*60}")
    print(f"Status Code: {response.status_code}")
    try:
        print(f"Response: {json.dumps(response.json(), indent=2)}")
    except:
        print(f"Response: {response.text}")
    print(f"{'='*60}\n")

def test_health_check():
    """Test API health"""
    print("\n🏥 Testing Health Check...")
    response = requests.get(f"{BASE_URL}/health")
    print_response("Health Check", response)
    return response.status_code == 200

def test_signup():
    """Test user registration"""
    print("\n👤 Testing User Signup...")
    
    signup_data = {
        "email": TEST_EMAIL,
        "password": TEST_PASSWORD,
        "full_name": "IAGI Warrior",
        "phone": "+919876543210"
    }
    
    response = requests.post(f"{BASE_URL}/auth/signup", json=signup_data)
    print_response("User Signup", response)
    
    return response.status_code in [200, 201]

def test_login():
    """Test user login and get token"""
    global TOKEN
    
    print("\n🔐 Testing User Login...")
    
    login_data = {
        "email": TEST_EMAIL,
        "password": TEST_PASSWORD
    }
    
    response = requests.post(f"{BASE_URL}/auth/login", json=login_data)
    print_response("User Login", response)
    
    if response.status_code == 200:
        TOKEN = response.json().get("access_token")
        print(f"✅ Token obtained: {TOKEN[:50]}...")
        return True
    return False

def test_get_profile():
    """Test getting current user profile"""
    print("\n👤 Testing Get Profile...")
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    response = requests.get(f"{BASE_URL}/auth/me", headers=headers)
    print_response("Get Profile", response)
    
    return response.status_code == 200

def test_update_profile():
    """Test updating user profile"""
    print("\n✏️ Testing Update Profile...")
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    profile_data = {
        "full_name": "IAGI Warrior Pro",
        "phone": "+919876543210",
        "bio": "Love traveling across India! 🇮🇳"
    }
    
    response = requests.put(f"{BASE_URL}/profile", json=profile_data, headers=headers)
    print_response("Update Profile", response)
    
    return response.status_code == 200

def test_create_booking():
    """Test creating a travel booking"""
    print("\n🎫 Testing Create Booking...")
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    
    departure = date.today() + timedelta(days=30)
    return_date = departure + timedelta(days=7)
    
    booking_data = {
        "from_state": "Delhi",
        "to_state": "Goa",
        "transport_mode": "flight",
        "departure_date": departure.isoformat(),
        "return_date": return_date.isoformat(),
        "travelers": 2,
        "travel_class": "economy",
        "total_amount": 15000.00
    }
    
    response = requests.post(f"{BASE_URL}/bookings", json=booking_data, headers=headers)
    print_response("Create Booking", response)
    
    if response.status_code in [200, 201]:
        booking_id = response.json().get("booking", {}).get("id")
        print(f"✅ Booking created with ID: {booking_id}")
        return booking_id
    return None

def test_get_bookings():
    """Test getting all user bookings"""
    print("\n📋 Testing Get All Bookings...")
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    response = requests.get(f"{BASE_URL}/bookings", headers=headers)
    print_response("Get All Bookings", response)
    
    return response.status_code == 200

def test_get_booking_by_id(booking_id):
    """Test getting specific booking"""
    print(f"\n🔍 Testing Get Booking by ID: {booking_id}...")
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    response = requests.get(f"{BASE_URL}/bookings/{booking_id}", headers=headers)
    print_response("Get Booking by ID", response)
    
    return response.status_code == 200

def test_update_booking(booking_id):
    """Test updating booking"""
    print(f"\n📝 Testing Update Booking: {booking_id}...")
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    update_data = {
        "status": "confirmed",
        "notes": "Looking forward to this trip!"
    }
    
    response = requests.put(f"{BASE_URL}/bookings/{booking_id}", json=update_data, headers=headers)
    print_response("Update Booking", response)
    
    return response.status_code == 200

def test_create_review():
    """Test creating a state review"""
    print("\n⭐ Testing Create Review...")
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    review_data = {
        "state_name": "Goa",
        "rating": 5,
        "review_text": "Amazing beaches and vibrant nightlife! Loved every moment in Goa. The food, culture, and people were incredible. Highly recommended for beach lovers!",
        "visited_places": ["Baga Beach", "Fort Aguada", "Dudhsagar Falls", "Old Goa Churches"]
    }
    
    response = requests.post(f"{BASE_URL}/reviews", json=review_data, headers=headers)
    print_response("Create Review", response)
    
    return response.status_code in [200, 201]

def test_get_state_reviews():
    """Test getting reviews for a state"""
    print("\n📖 Testing Get State Reviews...")
    
    response = requests.get(f"{BASE_URL}/reviews/Goa")
    print_response("Get State Reviews (Goa)", response)
    
    return response.status_code == 200

def test_get_popular_states():
    """Test getting popular states analytics"""
    print("\n📊 Testing Get Popular States...")
    
    response = requests.get(f"{BASE_URL}/analytics/popular-states")
    print_response("Get Popular States", response)
    
    return response.status_code == 200

def test_get_user_stats():
    """Test getting user statistics"""
    print("\n📈 Testing Get User Stats...")
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    response = requests.get(f"{BASE_URL}/analytics/user-stats", headers=headers)
    print_response("Get User Stats", response)
    
    return response.status_code == 200

def test_upload_photo():
    """Test photo upload (demonstration - requires actual file)"""
    print("\n📸 Testing Photo Upload (Skipped - requires file)...")
    print("To test photo upload:")
    print("""
    import requests
    
    headers = {"Authorization": f"Bearer {TOKEN}"}
    files = {"file": open("photo.jpg", "rb")}
    data = {"state_name": "Goa", "caption": "Beautiful sunset at Baga Beach"}
    
    response = requests.post(
        f"{BASE_URL}/upload/photo",
        headers=headers,
        files=files,
        data=data
    )
    print(response.json())
    """)
    return True

def run_all_tests():
    """Run all test cases"""
    print("\n" + "="*60)
    print("🚀 IAGI WARRIORS TRAVEL API - SUPABASE TEST SUITE")
    print("="*60)
    
    results = {}
    
    # Health Check
    results["Health Check"] = test_health_check()
    
    # Authentication Flow
    results["Signup"] = test_signup()
    results["Login"] = test_login()
    
    if not TOKEN:
        print("\n❌ Cannot continue tests without authentication token")
        return
    
    # Profile Management
    results["Get Profile"] = test_get_profile()
    results["Update Profile"] = test_update_profile()
    
    # Booking Management
    booking_id = test_create_booking()
    results["Create Booking"] = booking_id is not None
    
    if booking_id:
        results["Get Bookings"] = test_get_bookings()
        results["Get Booking by ID"] = test_get_booking_by_id(booking_id)
        results["Update Booking"] = test_update_booking(booking_id)
    
    # Reviews
    results["Create Review"] = test_create_review()
    results["Get State Reviews"] = test_get_state_reviews()
    
    # Analytics
    results["Get Popular States"] = test_get_popular_states()
    results["Get User Stats"] = test_get_user_stats()
    
    # Photo Upload
    results["Photo Upload Demo"] = test_upload_photo()
    
    # Print Summary
    print("\n" + "="*60)
    print("📊 TEST RESULTS SUMMARY")
    print("="*60)
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\n{'='*60}")
    print(f"Total: {passed}/{total} tests passed ({(passed/total)*100:.1f}%)")
    print(f"{'='*60}\n")

if __name__ == "__main__":
    try:
        run_all_tests()
    except KeyboardInterrupt:
        print("\n\n⚠️ Tests interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Error running tests: {str(e)}")
        import traceback
        traceback.print_exc()
