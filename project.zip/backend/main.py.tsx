"""
IAGI Warriors Travel Planning - Supabase Backend
FastAPI + Supabase Python SDK Integration

Features:
- User Authentication (Signup, Login, Logout)
- Travel Bookings Management
- State & District Data
- User Profiles
- File Upload (Travel Photos)
- Real-time Updates
"""

from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime, date
import os
from supabase import create_client, Client
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize FastAPI
app = FastAPI(
    title="IAGI Warriors Travel API",
    description="Backend API for travel planning with Supabase",
    version="1.0.0"
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Supabase Client
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://your-project.supabase.co")
SUPABASE_KEY = os.getenv("SUPABASE_KEY", "your-anon-key")
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# Security
security = HTTPBearer()

# ============================================
# Pydantic Models (Request/Response Schemas)
# ============================================

class UserSignup(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserProfile(BaseModel):
    full_name: str
    phone: Optional[str] = None
    bio: Optional[str] = None
    avatar_url: Optional[str] = None

class BookingCreate(BaseModel):
    from_state: str
    to_state: str
    transport_mode: str  # flight, train, bus, car, bike
    departure_date: date
    return_date: date
    travelers: int
    travel_class: Optional[str] = "economy"
    status: Optional[str] = "pending"
    total_amount: Optional[float] = 0.0

class BookingUpdate(BaseModel):
    status: Optional[str] = None
    total_amount: Optional[float] = None
    notes: Optional[str] = None

class StateReview(BaseModel):
    state_name: str
    rating: int  # 1-5
    review_text: str
    visited_places: Optional[List[str]] = []

class TravelPhoto(BaseModel):
    state_name: str
    caption: Optional[str] = None

# ============================================
# Authentication Helpers
# ============================================

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify JWT token and get current user"""
    try:
        token = credentials.credentials
        user = supabase.auth.get_user(token)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials"
            )
        return user
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Could not validate credentials: {str(e)}"
        )

# ============================================
# Authentication Endpoints
# ============================================

@app.post("/auth/signup", tags=["Authentication"])
async def signup(user_data: UserSignup):
    """
    Register a new user
    
    Creates user in Supabase Auth and profile in public.profiles table
    """
    try:
        # Create user with Supabase Auth
        auth_response = supabase.auth.sign_up({
            "email": user_data.email,
            "password": user_data.password,
            "options": {
                "data": {
                    "full_name": user_data.full_name,
                    "phone": user_data.phone
                }
            }
        })
        
        if not auth_response.user:
            raise HTTPException(status_code=400, detail="Failed to create user")
        
        # Create user profile
        profile_data = {
            "id": auth_response.user.id,
            "email": user_data.email,
            "full_name": user_data.full_name,
            "phone": user_data.phone,
            "created_at": datetime.utcnow().isoformat()
        }
        
        supabase.table("profiles").insert(profile_data).execute()
        
        return {
            "message": "User created successfully",
            "user": auth_response.user,
            "session": auth_response.session
        }
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/auth/login", tags=["Authentication"])
async def login(credentials: UserLogin):
    """
    Login user with email and password
    
    Returns JWT access token and refresh token
    """
    try:
        auth_response = supabase.auth.sign_in_with_password({
            "email": credentials.email,
            "password": credentials.password
        })
        
        if not auth_response.session:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        return {
            "message": "Login successful",
            "access_token": auth_response.session.access_token,
            "refresh_token": auth_response.session.refresh_token,
            "user": auth_response.user
        }
    
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))

@app.post("/auth/logout", tags=["Authentication"])
async def logout(user=Depends(get_current_user)):
    """Logout current user and invalidate session"""
    try:
        supabase.auth.sign_out()
        return {"message": "Logout successful"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/auth/me", tags=["Authentication"])
async def get_me(user=Depends(get_current_user)):
    """Get current user profile"""
    try:
        profile = supabase.table("profiles").select("*").eq("id", user.user.id).single().execute()
        return profile.data
    except Exception as e:
        raise HTTPException(status_code=404, detail="Profile not found")

# ============================================
# User Profile Endpoints
# ============================================

@app.put("/profile", tags=["Profile"])
async def update_profile(profile_data: UserProfile, user=Depends(get_current_user)):
    """Update user profile"""
    try:
        updated_profile = supabase.table("profiles").update({
            "full_name": profile_data.full_name,
            "phone": profile_data.phone,
            "bio": profile_data.bio,
            "avatar_url": profile_data.avatar_url,
            "updated_at": datetime.utcnow().isoformat()
        }).eq("id", user.user.id).execute()
        
        return {
            "message": "Profile updated successfully",
            "profile": updated_profile.data
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ============================================
# Booking Management Endpoints
# ============================================

@app.post("/bookings", tags=["Bookings"])
async def create_booking(booking: BookingCreate, user=Depends(get_current_user)):
    """Create a new travel booking"""
    try:
        booking_data = {
            "user_id": user.user.id,
            "from_state": booking.from_state,
            "to_state": booking.to_state,
            "transport_mode": booking.transport_mode,
            "departure_date": booking.departure_date.isoformat(),
            "return_date": booking.return_date.isoformat(),
            "travelers": booking.travelers,
            "travel_class": booking.travel_class,
            "status": booking.status,
            "total_amount": booking.total_amount,
            "created_at": datetime.utcnow().isoformat()
        }
        
        result = supabase.table("bookings").insert(booking_data).execute()
        
        return {
            "message": "Booking created successfully",
            "booking": result.data[0]
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/bookings", tags=["Bookings"])
async def get_bookings(
    status: Optional[str] = None,
    limit: int = 10,
    offset: int = 0,
    user=Depends(get_current_user)
):
    """Get all bookings for current user with optional filtering"""
    try:
        query = supabase.table("bookings").select("*").eq("user_id", user.user.id)
        
        if status:
            query = query.eq("status", status)
        
        query = query.order("created_at", desc=True).range(offset, offset + limit - 1)
        
        result = query.execute()
        
        return {
            "bookings": result.data,
            "count": len(result.data)
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/bookings/{booking_id}", tags=["Bookings"])
async def get_booking(booking_id: str, user=Depends(get_current_user)):
    """Get specific booking by ID"""
    try:
        result = supabase.table("bookings").select("*").eq("id", booking_id).eq("user_id", user.user.id).single().execute()
        
        if not result.data:
            raise HTTPException(status_code=404, detail="Booking not found")
        
        return result.data
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

@app.put("/bookings/{booking_id}", tags=["Bookings"])
async def update_booking(
    booking_id: str,
    booking_update: BookingUpdate,
    user=Depends(get_current_user)
):
    """Update booking status or details"""
    try:
        update_data = {
            "updated_at": datetime.utcnow().isoformat()
        }
        
        if booking_update.status:
            update_data["status"] = booking_update.status
        if booking_update.total_amount:
            update_data["total_amount"] = booking_update.total_amount
        if booking_update.notes:
            update_data["notes"] = booking_update.notes
        
        result = supabase.table("bookings").update(update_data).eq("id", booking_id).eq("user_id", user.user.id).execute()
        
        return {
            "message": "Booking updated successfully",
            "booking": result.data[0]
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/bookings/{booking_id}", tags=["Bookings"])
async def delete_booking(booking_id: str, user=Depends(get_current_user)):
    """Delete/cancel a booking"""
    try:
        supabase.table("bookings").delete().eq("id", booking_id).eq("user_id", user.user.id).execute()
        
        return {"message": "Booking deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ============================================
# State Reviews & Ratings
# ============================================

@app.post("/reviews", tags=["Reviews"])
async def create_review(review: StateReview, user=Depends(get_current_user)):
    """Create a review for a state"""
    try:
        review_data = {
            "user_id": user.user.id,
            "state_name": review.state_name,
            "rating": review.rating,
            "review_text": review.review_text,
            "visited_places": review.visited_places,
            "created_at": datetime.utcnow().isoformat()
        }
        
        result = supabase.table("reviews").insert(review_data).execute()
        
        return {
            "message": "Review created successfully",
            "review": result.data[0]
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/reviews/{state_name}", tags=["Reviews"])
async def get_state_reviews(state_name: str, limit: int = 10, offset: int = 0):
    """Get all reviews for a specific state"""
    try:
        result = supabase.table("reviews").select("*, profiles(full_name, avatar_url)").eq("state_name", state_name).order("created_at", desc=True).range(offset, offset + limit - 1).execute()
        
        return {
            "state": state_name,
            "reviews": result.data,
            "count": len(result.data)
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ============================================
# File Upload (Storage)
# ============================================

@app.post("/upload/photo", tags=["Storage"])
async def upload_travel_photo(
    file: UploadFile = File(...),
    state_name: str = None,
    caption: str = None,
    user=Depends(get_current_user)
):
    """Upload travel photo to Supabase Storage"""
    try:
        # Read file content
        file_content = await file.read()
        
        # Generate unique filename
        file_extension = file.filename.split(".")[-1]
        filename = f"{user.user.id}/{state_name}_{datetime.now().timestamp()}.{file_extension}"
        
        # Upload to Supabase Storage
        storage_response = supabase.storage.from_("travel-photos").upload(
            filename,
            file_content,
            {"content-type": file.content_type}
        )
        
        # Get public URL
        public_url = supabase.storage.from_("travel-photos").get_public_url(filename)
        
        # Save metadata to database
        photo_data = {
            "user_id": user.user.id,
            "state_name": state_name,
            "photo_url": public_url,
            "caption": caption,
            "filename": filename,
            "created_at": datetime.utcnow().isoformat()
        }
        
        supabase.table("travel_photos").insert(photo_data).execute()
        
        return {
            "message": "Photo uploaded successfully",
            "url": public_url
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/photos/{state_name}", tags=["Storage"])
async def get_state_photos(state_name: str, limit: int = 20):
    """Get all photos for a specific state"""
    try:
        result = supabase.table("travel_photos").select("*, profiles(full_name, avatar_url)").eq("state_name", state_name).order("created_at", desc=True).limit(limit).execute()
        
        return {
            "state": state_name,
            "photos": result.data
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ============================================
# Analytics & Statistics
# ============================================

@app.get("/analytics/popular-states", tags=["Analytics"])
async def get_popular_states():
    """Get most popular travel destinations"""
    try:
        # This uses a Supabase function or aggregated query
        result = supabase.rpc("get_popular_states").execute()
        return result.data
    except Exception as e:
        # Fallback: Count bookings per state
        result = supabase.table("bookings").select("to_state").execute()
        states = {}
        for booking in result.data:
            state = booking["to_state"]
            states[state] = states.get(state, 0) + 1
        
        popular = sorted(states.items(), key=lambda x: x[1], reverse=True)[:10]
        return [{"state": s[0], "count": s[1]} for s in popular]

@app.get("/analytics/user-stats", tags=["Analytics"])
async def get_user_stats(user=Depends(get_current_user)):
    """Get statistics for current user"""
    try:
        # Total bookings
        bookings = supabase.table("bookings").select("id", count="exact").eq("user_id", user.user.id).execute()
        
        # Total reviews
        reviews = supabase.table("reviews").select("id", count="exact").eq("user_id", user.user.id).execute()
        
        # Total photos
        photos = supabase.table("travel_photos").select("id", count="exact").eq("user_id", user.user.id).execute()
        
        return {
            "total_bookings": bookings.count,
            "total_reviews": reviews.count,
            "total_photos": photos.count
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ============================================
# Health Check
# ============================================

@app.get("/", tags=["Health"])
async def root():
    """API Health Check"""
    return {
        "status": "online",
        "service": "IAGI Warriors Travel API",
        "version": "1.0.0",
        "supabase_connected": True
    }

@app.get("/health", tags=["Health"])
async def health_check():
    """Detailed health check including Supabase connection"""
    try:
        # Test Supabase connection
        supabase.table("profiles").select("id").limit(1).execute()
        
        return {
            "status": "healthy",
            "database": "connected",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "database": "disconnected",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
