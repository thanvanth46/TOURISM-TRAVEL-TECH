# IAGI Warriors Travel Planning - Backend Setup Guide

## 🚀 Quick Start

### Prerequisites
- Python 3.9 or higher
- Supabase account (free tier available at https://supabase.com)
- pip (Python package manager)

### Installation Steps

#### 1. Install Dependencies
```bash
cd backend
pip install -r requirements.txt
```

#### 2. Set Up Supabase

**Create a Supabase Project:**
1. Go to https://supabase.com and sign up
2. Create a new project
3. Wait for the database to be provisioned

**Run Database Schema:**
1. Go to Supabase Dashboard → SQL Editor
2. Copy contents of `database_schema.sql`
3. Run the SQL to create tables, functions, and policies

**Create Storage Bucket:**
1. Go to Storage in Supabase Dashboard
2. Create a new bucket named `travel-photos`
3. Make it public
4. Set up the storage policies from the schema file

**Get API Credentials:**
1. Go to Settings → API
2. Copy your `Project URL` (SUPABASE_URL)
3. Copy your `anon public` key (SUPABASE_KEY)
4. Copy your `service_role` key (SUPABASE_SERVICE_KEY) - keep this secret!

#### 3. Configure Environment Variables
```bash
cp .env.example .env
# Edit .env with your Supabase credentials
nano .env
```

Update these values in `.env`:
```env
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_KEY=your-anon-key
SUPABASE_SERVICE_KEY=your-service-role-key
```

#### 4. Run the API Server
```bash
python main.py
```

Or with uvicorn directly:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`

#### 5. Access API Documentation
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

---

## 📚 API Endpoints Overview

### Authentication
- `POST /auth/signup` - Register new user
- `POST /auth/login` - Login and get JWT token
- `POST /auth/logout` - Logout user
- `GET /auth/me` - Get current user profile

### Profile Management
- `PUT /profile` - Update user profile

### Bookings
- `POST /bookings` - Create new booking
- `GET /bookings` - Get all user bookings
- `GET /bookings/{id}` - Get specific booking
- `PUT /bookings/{id}` - Update booking
- `DELETE /bookings/{id}` - Delete booking

### Reviews & Ratings
- `POST /reviews` - Create state review
- `GET /reviews/{state_name}` - Get all reviews for a state

### Photo Upload
- `POST /upload/photo` - Upload travel photo
- `GET /photos/{state_name}` - Get photos for a state

### Analytics
- `GET /analytics/popular-states` - Get popular destinations
- `GET /analytics/user-stats` - Get user statistics

---

## 🧪 Testing the API

### Using cURL

**Register a new user:**
```bash
curl -X POST http://localhost:8000/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "SecurePass123!",
    "full_name": "John Doe",
    "phone": "+919876543210"
  }'
```

**Login:**
```bash
curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "SecurePass123!"
  }'
```

**Create a booking (with JWT token):**
```bash
curl -X POST http://localhost:8000/bookings \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "from_state": "Delhi",
    "to_state": "Goa",
    "transport_mode": "flight",
    "departure_date": "2026-03-15",
    "return_date": "2026-03-20",
    "travelers": 2,
    "travel_class": "economy"
  }'
```

### Using Python Requests

```python
import requests

# Base URL
BASE_URL = "http://localhost:8000"

# 1. Signup
signup_data = {
    "email": "test@example.com",
    "password": "SecurePass123!",
    "full_name": "John Doe"
}
response = requests.post(f"{BASE_URL}/auth/signup", json=signup_data)
print("Signup:", response.json())

# 2. Login
login_data = {
    "email": "test@example.com",
    "password": "SecurePass123!"
}
response = requests.post(f"{BASE_URL}/auth/login", json=login_data)
token = response.json()["access_token"]
print("Token:", token)

# 3. Create booking
headers = {"Authorization": f"Bearer {token}"}
booking_data = {
    "from_state": "Delhi",
    "to_state": "Goa",
    "transport_mode": "flight",
    "departure_date": "2026-03-15",
    "return_date": "2026-03-20",
    "travelers": 2
}
response = requests.post(f"{BASE_URL}/bookings", json=booking_data, headers=headers)
print("Booking:", response.json())

# 4. Get all bookings
response = requests.get(f"{BASE_URL}/bookings", headers=headers)
print("Bookings:", response.json())
```

---

## 🔒 Security Features

### Row Level Security (RLS)
All tables have RLS enabled to ensure users can only access their own data.

### JWT Authentication
- Access tokens expire after 30 minutes
- Refresh tokens for extended sessions
- Secure password hashing with bcrypt

### Input Validation
- Pydantic models validate all input data
- SQL injection prevention
- XSS protection

---

## 🗄️ Database Schema

### Tables
1. **profiles** - User profile information
2. **bookings** - Travel booking records
3. **reviews** - State reviews and ratings
4. **travel_photos** - User-uploaded photos
5. **favorites** - Saved/favorite states
6. **states_info** - Static state information

### Key Features
- UUID primary keys
- Foreign key relationships
- Automatic timestamps (created_at, updated_at)
- Full-text search on reviews
- Composite indexes for performance

---

## 🔄 Real-time Features

Enable real-time subscriptions in Supabase:

```sql
ALTER PUBLICATION supabase_realtime ADD TABLE public.bookings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.reviews;
```

Then subscribe from frontend:
```javascript
const channel = supabase
  .channel('public:bookings')
  .on('postgres_changes', 
    { event: '*', schema: 'public', table: 'bookings' },
    (payload) => console.log('Change received!', payload)
  )
  .subscribe()
```

---

## 📊 Database Functions

### Get Popular States
```sql
SELECT * FROM get_popular_states(10);
```

### Get User Travel Score
```sql
SELECT get_user_travel_score('user-uuid-here');
```

---

## 🚀 Deployment

### Option 1: Docker
```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

Build and run:
```bash
docker build -t iagi-warriors-api .
docker run -p 8000:8000 --env-file .env iagi-warriors-api
```

### Option 2: Railway/Render/Fly.io
1. Connect your GitHub repository
2. Add environment variables
3. Deploy automatically

### Option 3: AWS/GCP/Azure
Use their respective Python hosting services with the requirements.txt

---

## 🐛 Troubleshooting

**Issue: "Could not connect to Supabase"**
- Check your SUPABASE_URL and SUPABASE_KEY in .env
- Ensure your Supabase project is active

**Issue: "JWT token invalid"**
- Token may have expired (30 min default)
- Use refresh token to get new access token
- Check token format: "Bearer YOUR_TOKEN"

**Issue: "Row Level Security policy violation"**
- Ensure you're authenticated
- Check RLS policies in Supabase
- User must own the resource they're accessing

---

## 📝 License
MIT License - Feel free to use for your projects!

## 🤝 Contributing
Pull requests welcome! Please test thoroughly before submitting.

## 📧 Support
For issues, please open a GitHub issue or contact support.

---

**Happy Coding! 🚀 IAGI Warriors Travel Planning**
