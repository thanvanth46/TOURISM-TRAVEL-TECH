-- ============================================
-- IAGI Warriors Travel Planning - Supabase Database Schema
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- Profiles Table
-- ============================================
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    bio TEXT,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policies for profiles
CREATE POLICY "Public profiles are viewable by everyone"
    ON public.profiles FOR SELECT
    USING (true);

CREATE POLICY "Users can update their own profile"
    ON public.profiles FOR UPDATE
    USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
    ON public.profiles FOR INSERT
    WITH CHECK (auth.uid() = id);

-- ============================================
-- Bookings Table
-- ============================================
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    from_state TEXT NOT NULL,
    to_state TEXT NOT NULL,
    transport_mode TEXT NOT NULL CHECK (transport_mode IN ('flight', 'train', 'bus', 'car', 'bike', 'ship')),
    departure_date DATE NOT NULL,
    return_date DATE NOT NULL,
    travelers INTEGER NOT NULL DEFAULT 1,
    travel_class TEXT DEFAULT 'economy',
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
    total_amount DECIMAL(10, 2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- Policies for bookings
CREATE POLICY "Users can view their own bookings"
    ON public.bookings FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own bookings"
    ON public.bookings FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bookings"
    ON public.bookings FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own bookings"
    ON public.bookings FOR DELETE
    USING (auth.uid() = user_id);

-- Indexes for better query performance
CREATE INDEX idx_bookings_user_id ON public.bookings(user_id);
CREATE INDEX idx_bookings_status ON public.bookings(status);
CREATE INDEX idx_bookings_departure_date ON public.bookings(departure_date);

-- ============================================
-- Reviews Table
-- ============================================
CREATE TABLE IF NOT EXISTS public.reviews (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    state_name TEXT NOT NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT NOT NULL,
    visited_places TEXT[],
    helpful_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- Policies for reviews
CREATE POLICY "Reviews are viewable by everyone"
    ON public.reviews FOR SELECT
    USING (true);

CREATE POLICY "Users can create reviews"
    ON public.reviews FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own reviews"
    ON public.reviews FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own reviews"
    ON public.reviews FOR DELETE
    USING (auth.uid() = user_id);

-- Indexes for reviews
CREATE INDEX idx_reviews_user_id ON public.reviews(user_id);
CREATE INDEX idx_reviews_state_name ON public.reviews(state_name);
CREATE INDEX idx_reviews_rating ON public.reviews(rating);

-- ============================================
-- Travel Photos Table
-- ============================================
CREATE TABLE IF NOT EXISTS public.travel_photos (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    state_name TEXT NOT NULL,
    photo_url TEXT NOT NULL,
    caption TEXT,
    filename TEXT NOT NULL,
    likes_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.travel_photos ENABLE ROW LEVEL SECURITY;

-- Policies for photos
CREATE POLICY "Photos are viewable by everyone"
    ON public.travel_photos FOR SELECT
    USING (true);

CREATE POLICY "Users can upload photos"
    ON public.travel_photos FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own photos"
    ON public.travel_photos FOR DELETE
    USING (auth.uid() = user_id);

-- Indexes for photos
CREATE INDEX idx_photos_user_id ON public.travel_photos(user_id);
CREATE INDEX idx_photos_state_name ON public.travel_photos(state_name);

-- ============================================
-- Favorites Table (Saved States)
-- ============================================
CREATE TABLE IF NOT EXISTS public.favorites (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    state_name TEXT NOT NULL,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, state_name)
);

-- Enable Row Level Security
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;

-- Policies for favorites
CREATE POLICY "Users can view their own favorites"
    ON public.favorites FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can add favorites"
    ON public.favorites FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove favorites"
    ON public.favorites FOR DELETE
    USING (auth.uid() = user_id);

-- ============================================
-- Database Functions
-- ============================================

-- Function to get popular states based on bookings
CREATE OR REPLACE FUNCTION get_popular_states(limit_count INTEGER DEFAULT 10)
RETURNS TABLE (
    state_name TEXT,
    booking_count BIGINT,
    avg_rating NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        b.to_state,
        COUNT(b.id) as booking_count,
        COALESCE(AVG(r.rating), 0) as avg_rating
    FROM public.bookings b
    LEFT JOIN public.reviews r ON b.to_state = r.state_name
    GROUP BY b.to_state
    ORDER BY booking_count DESC, avg_rating DESC
    LIMIT limit_count;
END;
$$ LANGUAGE plpgsql;

-- Function to calculate user travel score
CREATE OR REPLACE FUNCTION get_user_travel_score(user_uuid UUID)
RETURNS INTEGER AS $$
DECLARE
    score INTEGER := 0;
    booking_count INTEGER;
    review_count INTEGER;
    photo_count INTEGER;
BEGIN
    -- Count bookings (5 points each)
    SELECT COUNT(*) INTO booking_count
    FROM public.bookings
    WHERE user_id = user_uuid;
    score := score + (booking_count * 5);
    
    -- Count reviews (10 points each)
    SELECT COUNT(*) INTO review_count
    FROM public.reviews
    WHERE user_id = user_uuid;
    score := score + (review_count * 10);
    
    -- Count photos (3 points each)
    SELECT COUNT(*) INTO photo_count
    FROM public.travel_photos
    WHERE user_id = user_uuid;
    score := score + (photo_count * 3);
    
    RETURN score;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- Triggers
-- ============================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to tables with updated_at
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at
    BEFORE UPDATE ON public.bookings
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_reviews_updated_at
    BEFORE UPDATE ON public.reviews
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- Storage Buckets (Run in Supabase Dashboard)
-- ============================================

-- Create travel-photos bucket
-- INSERT INTO storage.buckets (id, name, public)
-- VALUES ('travel-photos', 'travel-photos', true);

-- Storage policies for travel-photos bucket
-- CREATE POLICY "Public Access"
-- ON storage.objects FOR SELECT
-- USING (bucket_id = 'travel-photos');

-- CREATE POLICY "Authenticated users can upload"
-- ON storage.objects FOR INSERT
-- WITH CHECK (bucket_id = 'travel-photos' AND auth.role() = 'authenticated');

-- CREATE POLICY "Users can delete their own photos"
-- ON storage.objects FOR DELETE
-- USING (bucket_id = 'travel-photos' AND auth.uid()::text = (storage.foldername(name))[1]);

-- ============================================
-- Seed Data (Optional)
-- ============================================

-- Insert sample states data
CREATE TABLE IF NOT EXISTS public.states_info (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    state_name TEXT UNIQUE NOT NULL,
    capital TEXT NOT NULL,
    description TEXT,
    famous_for TEXT[],
    best_time_to_visit TEXT,
    avg_budget_per_day INTEGER,
    popular_places TEXT[],
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Make states_info publicly readable
ALTER TABLE public.states_info ENABLE ROW LEVEL SECURITY;

CREATE POLICY "States info is viewable by everyone"
    ON public.states_info FOR SELECT
    USING (true);

-- Sample data for a few states
INSERT INTO public.states_info (state_name, capital, description, famous_for, best_time_to_visit, avg_budget_per_day, popular_places)
VALUES 
    ('Rajasthan', 'Jaipur', 'Land of Kings with majestic forts and palaces', 
     ARRAY['Forts', 'Palaces', 'Desert Safari', 'Heritage Hotels'], 
     'October to March', 2500, 
     ARRAY['Jaipur', 'Udaipur', 'Jaisalmer', 'Jodhpur']),
    
    ('Kerala', 'Thiruvananthapuram', 'Gods Own Country with backwaters and beaches', 
     ARRAY['Backwaters', 'Beaches', 'Ayurveda', 'Spice Gardens'], 
     'September to March', 3000, 
     ARRAY['Munnar', 'Alleppey', 'Kochi', 'Kovalam']),
    
    ('Goa', 'Panaji', 'Beach paradise and Portuguese heritage', 
     ARRAY['Beaches', 'Nightlife', 'Water Sports', 'Seafood'], 
     'November to February', 2000, 
     ARRAY['Baga Beach', 'Calangute', 'Old Goa', 'Dudhsagar Falls'])
ON CONFLICT (state_name) DO NOTHING;

-- ============================================
-- Real-time Subscriptions Setup
-- ============================================

-- Enable real-time for tables (Run in Supabase Dashboard > Database > Replication)
-- ALTER PUBLICATION supabase_realtime ADD TABLE public.bookings;
-- ALTER PUBLICATION supabase_realtime ADD TABLE public.reviews;
-- ALTER PUBLICATION supabase_realtime ADD TABLE public.travel_photos;

-- ============================================
-- Indexes for Performance
-- ============================================

-- Full-text search index for reviews
CREATE INDEX idx_reviews_text_search ON public.reviews USING gin(to_tsvector('english', review_text));

-- Composite indexes
CREATE INDEX idx_bookings_user_status ON public.bookings(user_id, status);
CREATE INDEX idx_reviews_state_rating ON public.reviews(state_name, rating);

-- ============================================
-- Views for Analytics
-- ============================================

-- View for state statistics
CREATE OR REPLACE VIEW public.state_statistics AS
SELECT 
    r.state_name,
    COUNT(DISTINCT r.user_id) as total_reviewers,
    AVG(r.rating) as avg_rating,
    COUNT(r.id) as total_reviews,
    COUNT(DISTINCT p.id) as total_photos,
    COUNT(DISTINCT b.id) as total_bookings
FROM public.reviews r
LEFT JOIN public.travel_photos p ON r.state_name = p.state_name
LEFT JOIN public.bookings b ON r.state_name = b.to_state
GROUP BY r.state_name;

-- Grant access to view
GRANT SELECT ON public.state_statistics TO authenticated;
